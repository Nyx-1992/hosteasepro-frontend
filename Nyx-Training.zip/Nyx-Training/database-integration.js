/**
 * ============================================================
 * SUPABASE INTEGRATION SCRIPT FOR EXISTING SYSTEM
 * ============================================================
 * 
 * This script integrates Supabase database with your existing
 * property management system. It replaces localStorage operations
 * with database calls while maintaining the same interface.
 */

// ============================================================
// INTEGRATION FLAGS & SETTINGS
// ============================================================

let DATABASE_ENABLED = false;
let FALLBACK_TO_LOCALSTORAGE = true;
let MIGRATION_COMPLETED = false;

/**
 * Enable database integration
 * Call this after setting up Supabase credentials
 */
async function enableDatabase() {
    try {
        console.log('🔄 Enabling database integration...');
        
        // Test connection first
        const testResult = await database.migration.testConnection();
        if (!testResult.success) {
            throw new Error('Database connection failed: ' + testResult.error);
        }
        
        DATABASE_ENABLED = true;
        console.log('✅ Database integration enabled successfully');
        
        // Show success message to user
        showDatabaseStatus('✅ Database connected successfully!', 'success');
        
        return true;
    } catch (error) {
        console.error('❌ Failed to enable database:', error);
        showDatabaseStatus('❌ Database connection failed. Using local storage.', 'error');
        DATABASE_ENABLED = false;
        return false;
    }
}

/**
 * Migrate existing localStorage data to database
 */
async function migrateExistingData() {
    if (!DATABASE_ENABLED) {
        console.warn('⚠️ Database not enabled, cannot migrate data');
        return false;
    }
    
    try {
        console.log('🔄 Starting data migration...');
        showDatabaseStatus('🔄 Migrating existing data to database...', 'info');
        
        await database.migration.migrateLocalStorageData();
        
        MIGRATION_COMPLETED = true;
        console.log('✅ Data migration completed');
        showDatabaseStatus('✅ Data migration completed successfully!', 'success');
        
        // Refresh displays to show migrated data
        if (typeof displayPastBookings === 'function') {
            displayPastBookings();
        }
        
        return true;
    } catch (error) {
        console.error('❌ Data migration failed:', error);
        showDatabaseStatus('❌ Data migration failed: ' + error.message, 'error');
        return false;
    }
}

// ============================================================
// ENHANCED BOOKING FUNCTIONS
// ============================================================

/**
 * Enhanced displayPastBookings function with database integration
 */
async function displayPastBookingsDB() {
    console.log('📅 Displaying past bookings (database-enhanced)...');
    
    let allPastBookings = [];
    
    try {
        if (DATABASE_ENABLED) {
            // Get past bookings from database
            const dbBookings = await database.bookings.getPast();
            allPastBookings = dbBookings.map(booking => ({
                id: booking.id,
                guest_name: booking.guest_name,
                guest_email: booking.guest_email,
                guest_phone: booking.guest_phone,
                checkin: booking.checkin_date,
                checkout: booking.checkout_date,
                property: booking.properties?.name || 'Unknown Property',
                platform: booking.platform || 'Database Entry',
                total_amount: booking.total_amount ? `R${booking.total_amount}` : 'Amount not recorded',
                notes: booking.notes || '',
                domestic_service: booking.domestic_service_arranged
            }));
            
            console.log(`📊 Loaded ${allPastBookings.length} past bookings from database`);
        }
        
        // Fallback: Also get localStorage bookings if database fails or as backup
        if (FALLBACK_TO_LOCALSTORAGE || allPastBookings.length === 0) {
            const localBookings = JSON.parse(localStorage.getItem('pastBookings') || '[]');
            allPastBookings = [...allPastBookings, ...localBookings];
        }
        
    } catch (error) {
        console.error('❌ Error loading past bookings from database:', error);
        
        // Fallback to localStorage
        const localBookings = JSON.parse(localStorage.getItem('pastBookings') || '[]');
        allPastBookings = localBookings;
        
        showDatabaseStatus('⚠️ Using local storage fallback for past bookings', 'warning');
    }
    
    // Remove duplicates (in case of overlap between database and localStorage)
    allPastBookings = allPastBookings.filter((booking, index, self) => 
        index === self.findIndex(b => 
            b.guest_name === booking.guest_name && 
            b.checkin === booking.checkin && 
            b.checkout === booking.checkout
        )
    );
    
    // Display the bookings
    if (allPastBookings.length === 0) {
        document.getElementById('past-bookings-list').innerHTML = `
            <div style="text-align: center; padding: 40px; color: #666;">
                <h4>📅 No Past Bookings Found</h4>
                <p>Past bookings will appear here automatically when you have completed bookings.</p>
                <p style="font-size: 14px; color: #999;">
                    ${DATABASE_ENABLED ? '🟢 Database connected' : '🔴 Database offline (using local storage)'}
                </p>
            </div>
        `;
        return;
    }
    
    // Sort by check-out date (most recent first)
    allPastBookings.sort((a, b) => {
        const dateA = new Date(a.checkout);
        const dateB = new Date(b.checkout);
        return dateB - dateA;
    });
    
    let html = `
        <div style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
            <div>
                <h3>📅 Past Bookings (${allPastBookings.length} total)</h3>
                <p style="font-size: 14px; color: #666; margin: 5px 0;">
                    ${DATABASE_ENABLED ? '🟢 Database connected' : '🔴 Using local storage'}
                </p>
            </div>
            <div style="display: flex; gap: 10px;">
                <button onclick="addPastBooking()" style="background: #28a745; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-size: 14px;">
                    ➕ Add Booking
                </button>
                <button onclick="clearPastBookings()" style="background: #dc3545; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-size: 14px;">
                    🗑️ Clear All
                </button>
            </div>
        </div>
    `;
    
    allPastBookings.forEach((booking, index) => {
        const checkinDate = new Date(booking.checkin);
        const checkoutDate = new Date(booking.checkout);
        const nights = Math.ceil((checkoutDate - checkinDate) / (1000 * 60 * 60 * 24));
        
        html += `
            <div class="booking-card" style="background: #f8f9fa; border-left: 4px solid #6c757d; margin-bottom: 15px; padding: 15px; border-radius: 8px;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div style="flex: 1;">
                        <h4 style="margin: 0 0 5px 0; color: #495057;">
                            ${booking.guest_name}
                            <span style="font-size: 14px; color: #6c757d;">(${booking.property})</span>
                            <span style="background: #6c757d; color: white; padding: 2px 6px; border-radius: 8px; font-size: 10px; margin-left: 8px;">${booking.platform.toUpperCase()}</span>
                        </h4>
                        <p style="margin: 2px 0; color: #6c757d;">
                            📧 ${booking.guest_email || 'No email'} | 
                            📞 ${booking.guest_phone ? `${booking.guest_phone.substring(0, 3)}****${booking.guest_phone.substring(booking.guest_phone.length - 3)}` : 'No phone'}
                        </p>
                        <p style="margin: 2px 0;">
                            📅 ${booking.checkin} → ${booking.checkout} 
                            <span style="color: #28a745; font-weight: bold;">(${nights} night${nights !== 1 ? 's' : ''})</span>
                        </p>
                        <p style="margin: 2px 0; color: #6c757d;">
                            💰 ${booking.total_amount || 'Amount not recorded'}
                            ${DATABASE_ENABLED && booking.id ? ` | ID: ${booking.id}` : ''}
                        </p>
                        ${booking.domestic_service ? '<p style="margin: 2px 0; color: #28a745;">🧹 Domestic service arranged</p>' : ''}
                        ${booking.notes ? `<p style="margin: 5px 0; font-style: italic; color: #6c757d;">📝 ${booking.notes}</p>` : ''}
                    </div>
                    <div style="text-align: right;">
                        <span style="background: #6c757d; color: white; padding: 3px 8px; border-radius: 12px; font-size: 12px;">
                            COMPLETED
                        </span>
                        ${booking.id ? `<br><button onclick="editBooking('${booking.id}')" style="background: #007bff; color: white; border: none; padding: 4px 8px; border-radius: 4px; cursor: pointer; font-size: 11px; margin-top: 5px;">✏️ Edit</button>` : ''}
                    </div>
                </div>
            </div>
        `;
    });
    
    document.getElementById('past-bookings-list').innerHTML = html;
}

/**
 * Add new past booking (enhanced with database)
 */
async function addPastBookingDB() {
    const guestName = prompt('Guest Name:');
    if (!guestName) return;
    
    const guestEmail = prompt('Guest Email (optional):') || '';
    const guestPhone = prompt('Guest Phone (optional):') || '';
    const checkin = prompt('Check-in Date (YYYY-MM-DD):');
    const checkout = prompt('Check-out Date (YYYY-MM-DD):');
    const property = prompt('Property (Speranta/TV House):') || 'Speranta';
    const platform = prompt('Booking Platform:') || 'Direct';
    const amount = prompt('Total Amount (without R):');
    const notes = prompt('Notes (optional):') || '';
    
    if (!checkin || !checkout) {
        alert('Check-in and check-out dates are required!');
        return;
    }
    
    const booking = {
        guest_name: guestName,
        guest_email: guestEmail,
        guest_phone: guestPhone,
        checkin_date: checkin,
        checkout_date: checkout,
        property_name: property,
        platform: platform,
        total_amount: amount ? parseFloat(amount) : null,
        notes: notes,
        status: 'completed'
    };
    
    try {
        if (DATABASE_ENABLED) {
            // Add to database
            const dbBooking = await database.bookings.add(booking);
            console.log('✅ Booking added to database:', dbBooking);
            showDatabaseStatus('✅ Booking saved to database', 'success');
        } else {
            // Fallback to localStorage
            const pastBookings = JSON.parse(localStorage.getItem('pastBookings') || '[]');
            const localBooking = {
                ...booking,
                checkin: booking.checkin_date,
                checkout: booking.checkout_date,
                property: booking.property_name
            };
            pastBookings.push(localBooking);
            localStorage.setItem('pastBookings', JSON.stringify(pastBookings));
            console.log('✅ Booking added to localStorage');
            showDatabaseStatus('✅ Booking saved locally', 'info');
        }
        
        // Refresh display
        displayPastBookingsDB();
        
    } catch (error) {
        console.error('❌ Error adding booking:', error);
        alert('Error adding booking: ' + error.message);
    }
}

// ============================================================
// DATABASE STATUS UI
// ============================================================

/**
 * Show database status message to user
 */
function showDatabaseStatus(message, type = 'info') {
    const statusDiv = document.getElementById('database-status') || createDatabaseStatusDiv();
    
    const colors = {
        success: { bg: '#d4edda', border: '#28a745', text: '#155724' },
        error: { bg: '#f8d7da', border: '#dc3545', text: '#721c24' },
        warning: { bg: '#fff3cd', border: '#ffc107', text: '#856404' },
        info: { bg: '#e3f2fd', border: '#007bff', text: '#004085' }
    };
    
    const color = colors[type] || colors.info;
    
    statusDiv.innerHTML = `
        <div style="background: ${color.bg}; border: 1px solid ${color.border}; border-radius: 4px; padding: 10px; margin: 10px 0; color: ${color.text}; font-size: 14px;">
            ${message}
        </div>
    `;
    
    // Auto-hide success/info messages after 5 seconds
    if (type === 'success' || type === 'info') {
        setTimeout(() => {
            statusDiv.innerHTML = '';
        }, 5000);
    }
}

/**
 * Create database status div if it doesn't exist
 */
function createDatabaseStatusDiv() {
    let statusDiv = document.getElementById('database-status');
    if (!statusDiv) {
        statusDiv = document.createElement('div');
        statusDiv.id = 'database-status';
        
        // Insert after the booking status div
        const bookingStatusDiv = document.getElementById('booking-status');
        if (bookingStatusDiv) {
            bookingStatusDiv.parentNode.insertBefore(statusDiv, bookingStatusDiv.nextSibling);
        } else {
            // Fallback: add to bookings tab
            const bookingsTab = document.getElementById('bookings-tab');
            if (bookingsTab) {
                bookingsTab.insertBefore(statusDiv, bookingsTab.firstChild);
            }
        }
    }
    return statusDiv;
}

// ============================================================
// ENHANCED DATABASE CONTROLS
// ============================================================

/**
 * Add database control panel to the bookings tab
 */
function addDatabaseControlPanel() {
    const controlsHtml = `
        <div id="database-controls" style="background: #f0f8ff; border: 1px solid #007bff; border-radius: 8px; padding: 15px; margin-bottom: 20px;">
            <h4 style="margin: 0 0 15px 0; color: #007bff;">🗄️ Database Management</h4>
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <button onclick="enableDatabase()" style="background: #28a745; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-size: 14px;">
                    🔗 Connect Database
                </button>
                <button onclick="migrateExistingData()" style="background: #007bff; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-size: 14px;">
                    📊 Migrate Data
                </button>
                <button onclick="testDatabaseConnection()" style="background: #17a2b8; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-size: 14px;">
                    🔍 Test Connection
                </button>
                <button onclick="showDatabaseStats()" style="background: #6f42c1; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-size: 14px;">
                    📈 Database Stats
                </button>
            </div>
            <div id="database-status" style="margin-top: 10px;"></div>
        </div>
    `;
    
    // Insert controls before the debugging system
    const debuggingSystem = document.querySelector('#bookings-tab .tab-content > div:first-child');
    if (debuggingSystem) {
        debuggingSystem.insertAdjacentHTML('beforebegin', controlsHtml);
    }
}

/**
 * Test database connection
 */
async function testDatabaseConnection() {
    showDatabaseStatus('🔄 Testing database connection...', 'info');
    
    try {
        const result = await database.migration.testConnection();
        if (result.success) {
            showDatabaseStatus(`✅ Database connected successfully! Found ${result.propertiesCount} properties.`, 'success');
        } else {
            showDatabaseStatus(`❌ Database connection failed: ${result.error}`, 'error');
        }
    } catch (error) {
        showDatabaseStatus(`❌ Connection test failed: ${error.message}`, 'error');
    }
}

/**
 * Show database statistics
 */
async function showDatabaseStats() {
    if (!DATABASE_ENABLED) {
        showDatabaseStatus('⚠️ Database not connected', 'warning');
        return;
    }
    
    try {
        showDatabaseStatus('🔄 Loading database statistics...', 'info');
        
        const properties = await database.properties.getAll();
        const bookings = await database.bookings.getAll();
        const contacts = await database.contacts.getAll();
        const domesticServices = await database.domesticServices.getAll();
        
        const stats = `
            📊 Database Statistics:<br>
            🏠 Properties: ${properties.length}<br>
            📅 Total Bookings: ${bookings.length}<br>
            👥 Contacts: ${contacts.length}<br>
            🧹 Domestic Services: ${domesticServices.length}
        `;
        
        showDatabaseStatus(stats, 'info');
        
    } catch (error) {
        showDatabaseStatus(`❌ Error loading stats: ${error.message}`, 'error');
    }
}

/**
 * Sync all data from database to localStorage
 */
async function syncFromDatabase() {
    if (!DATABASE_ENABLED) {
        console.log('⚠️ Database not enabled, skipping sync');
        return false;
    }
    
    try {
        console.log('🔄 Syncing data from database...');
        
        // Fetch all contacts from database
        const contacts = await database.contacts.getAll();
        console.log(`📥 Loaded ${contacts.length} contacts from database`);
        
        // Convert database format to localStorage format
        const contactsData = contacts.map(contact => ({
            name: contact.name,
            phone: contact.phone,
            email: contact.email,
            whatsapp: contact.whatsapp || contact.phone,
            category: contact.category,
            businessArea: contact.business_area,
            role: contact.role,
            propertiesServed: contact.properties_served || [],
            paymentMethod: contact.payment_method,
            isActive: contact.is_active !== false,
            notes: contact.notes
        }));
        
        // Save to localStorage in the format the app expects
        localStorage.setItem('guestContactData', JSON.stringify(contactsData));
        console.log('✅ Contacts synced to localStorage');
        
        // Fetch bookings if needed
        try {
            const bookings = await database.bookings.getAll();
            console.log(`📥 Loaded ${bookings.length} bookings from database`);
            
            // Convert and save bookings
            const bookingsData = bookings.map(booking => ({
                id: booking.id,
                propertyName: booking.property_id === 1 ? 'Speranta Property' : 'TV House Property',
                guestName: booking.guest_name,
                guestEmail: booking.guest_email,
                guestPhone: booking.guest_phone,
                checkinDate: booking.checkin_date,
                checkoutDate: booking.checkout_date,
                nights: booking.nights,
                platform: booking.platform,
                bookingReference: booking.booking_reference,
                totalAmount: booking.total_amount,
                currency: booking.currency,
                guestCount: booking.guest_count,
                status: booking.status,
                specialRequests: booking.special_requests,
                notes: booking.notes
            }));
            
            localStorage.setItem('pastBookings', JSON.stringify(bookingsData));
            console.log('✅ Bookings synced to localStorage');
        } catch (error) {
            console.warn('⚠️ Could not sync bookings:', error.message);
        }
        
        return true;
    } catch (error) {
        console.error('❌ Error syncing from database:', error);
        return false;
    }
}

// ============================================================
// INITIALIZE ENHANCED SYSTEM
// ============================================================

// Wait for page to load, then add database controls and enhance existing functions
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Initializing database integration...');
    
    // Add database control panel
    addDatabaseControlPanel();
    
    // Replace existing functions with enhanced versions
    if (typeof displayPastBookings !== 'undefined') {
        window.originalDisplayPastBookings = displayPastBookings;
        window.displayPastBookings = displayPastBookingsDB;
    }
    
    if (typeof addPastBooking !== 'undefined') {
        window.originalAddPastBooking = addPastBooking;
        window.addPastBooking = addPastBookingDB;
    }
    
    // Make functions globally available
    window.enableDatabase = enableDatabase;
    window.migrateExistingData = migrateExistingData;
    window.testDatabaseConnection = testDatabaseConnection;
    window.showDatabaseStats = showDatabaseStats;
    window.syncFromDatabase = syncFromDatabase;
    
    console.log('✅ Database integration initialized');
});

console.log('📦 Supabase integration script loaded');