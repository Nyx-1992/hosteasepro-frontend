const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch'); // You'll need: npm install node-fetch
require('dotenv').config(); // You'll need: npm install dotenv

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Booking.com API Integration
class BookingComAPI {
    constructor() {
        this.baseURL = 'https://distribution-xml.booking.com/json/bookings';
        this.username = process.env.BOOKING_COM_USERNAME;
        this.password = process.env.BOOKING_COM_PASSWORD;
        this.credentials = Buffer.from(`${this.username}:${this.password}`).toString('base64');
    }

    async getReservations(hotelId, startDate, endDate) {
        try {
            const url = `${this.baseURL}?hotel_ids=${hotelId}&checkin_from=${startDate}&checkin_to=${endDate}`;
            
            const response = await fetch(url, {
                method: 'GET',
                headers: {
                    'Authorization': `Basic ${this.credentials}`,
                    'Content-Type': 'application/json',
                    'User-Agent': 'HostEasePro/1.0'
                }
            });

            if (!response.ok) {
                throw new Error(`Booking.com API error: ${response.status} ${response.statusText}`);
            }

            const data = await response.json();
            return data;
        } catch (error) {
            console.error('Booking.com API Error:', error);
            throw error;
        }
    }

    async getReservationDetails(reservationId) {
        try {
            const url = `${this.baseURL}/${reservationId}`;
            
            const response = await fetch(url, {
                headers: {
                    'Authorization': `Basic ${this.credentials}`,
                    'Content-Type': 'application/json'
                }
            });

            return await response.json();
        } catch (error) {
            console.error('Booking.com reservation details error:', error);
            throw error;
        }
    }
}

// Airbnb API Integration (requires Partner API access)
class AirbnbAPI {
    constructor() {
        this.baseURL = 'https://api.airbnb.com/v2';
        this.clientId = process.env.AIRBNB_CLIENT_ID;
        this.accessToken = process.env.AIRBNB_ACCESS_TOKEN;
    }

    async getReservations() {
        try {
            const response = await fetch(`${this.baseURL}/reservations`, {
                headers: {
                    'Authorization': `Bearer ${this.accessToken}`,
                    'X-Airbnb-API-Key': this.clientId
                }
            });

            return await response.json();
        } catch (error) {
            console.error('Airbnb API Error:', error);
            throw error;
        }
    }

    async getPayouts(reservationId) {
        try {
            const response = await fetch(`${this.baseURL}/payouts?reservation_id=${reservationId}`, {
                headers: {
                    'Authorization': `Bearer ${this.accessToken}`,
                    'X-Airbnb-API-Key': this.clientId
                }
            });

            return await response.json();
        } catch (error) {
            console.error('Airbnb payouts error:', error);
            throw error;
        }
    }
}

// API Routes

// Get Booking.com reservations
app.get('/api/bookings/booking-com', async (req, res) => {
    try {
        const { property, start_date, end_date } = req.query;
        
        // Map property names to Booking.com hotel IDs
        const hotelIds = {
            'speranta': process.env.BOOKING_SPERANTA_ID,
            'tvhouse': process.env.BOOKING_TVHOUSE_ID
        };

        const hotelId = hotelIds[property] || hotelIds.speranta;
        
        const bookingAPI = new BookingComAPI();
        const reservations = await bookingAPI.getReservations(hotelId, start_date, end_date);
        
        // Process and format the data
        const processedReservations = reservations.map(reservation => ({
            id: reservation.reservation_id,
            property: property,
            platform: 'booking',
            guestName: `${reservation.booker_details.firstname} ${reservation.booker_details.lastname}`,
            phone: reservation.booker_details.telephone,
            email: reservation.booker_details.email,
            guestCount: reservation.room_reservations[0]?.no_of_guests || 1,
            checkinDate: reservation.checkin,
            checkoutDate: reservation.checkout,
            totalAmount: reservation.total_price,
            currency: reservation.currency,
            specialRequests: reservation.customer_comments || '',
            status: reservation.status,
            bookingReference: reservation.reservation_id
        }));

        res.json({
            success: true,
            data: processedReservations,
            count: processedReservations.length
        });

    } catch (error) {
        console.error('Booking.com API route error:', error);
        res.status(500).json({
            success: false,
            error: error.message,
            message: 'Failed to fetch Booking.com reservations'
        });
    }
});

// Get Airbnb reservations
app.get('/api/bookings/airbnb', async (req, res) => {
    try {
        const { property } = req.query;
        
        const airbnbAPI = new AirbnbAPI();
        const reservations = await airbnbAPI.getReservations();
        
        // Process Airbnb data (limited due to privacy restrictions)
        const processedReservations = reservations.reservations?.map(reservation => ({
            id: reservation.id,
            property: property,
            platform: 'airbnb',
            guestName: `${reservation.guest.first_name} (Airbnb Guest)`,
            phone: 'Available via Airbnb messaging only',
            email: 'Available via Airbnb messaging only',
            guestCount: reservation.guest_details.number_of_guests,
            checkinDate: reservation.start_date,
            checkoutDate: reservation.end_date,
            hostPayout: reservation.payout?.amount || 0,
            platformFee: reservation.payout?.host_fee || 0,
            specialRequests: reservation.special_requests || '',
            status: reservation.status,
            bookingReference: reservation.id
        })) || [];

        res.json({
            success: true,
            data: processedReservations,
            count: processedReservations.length
        });

    } catch (error) {
        console.error('Airbnb API route error:', error);
        res.status(500).json({
            success: false,
            error: error.message,
            message: 'Failed to fetch Airbnb reservations'
        });
    }
});

// Get combined revenue report
app.get('/api/reports/revenue', async (req, res) => {
    try {
        const { month, year } = req.query;
        const startDate = `${year}-${month.padStart(2, '0')}-01`;
        const endDate = `${year}-${month.padStart(2, '0')}-31`;

        // Fetch from both platforms
        const [bookingComSperanta, bookingComTVHouse, airbnbData] = await Promise.all([
            new BookingComAPI().getReservations(process.env.BOOKING_SPERANTA_ID, startDate, endDate),
            new BookingComAPI().getReservations(process.env.BOOKING_TVHOUSE_ID, startDate, endDate),
            new AirbnbAPI().getReservations()
        ]);

        // Calculate revenue metrics
        const report = {
            totalRevenue: 0,
            platformBreakdown: {
                'booking.com': 0,
                'airbnb': 0
            },
            propertyBreakdown: {
                'speranta': 0,
                'tvhouse': 0
            },
            totalBookings: 0,
            averageBookingValue: 0
        };

        // Process Booking.com data
        [...bookingComSperanta, ...bookingComTVHouse].forEach(reservation => {
            report.totalRevenue += reservation.total_price;
            report.platformBreakdown['booking.com'] += reservation.total_price;
            report.totalBookings++;
        });

        // Process Airbnb data (filter by date range)
        airbnbData.reservations?.forEach(reservation => {
            const checkinDate = new Date(reservation.start_date);
            if (checkinDate >= new Date(startDate) && checkinDate <= new Date(endDate)) {
                const payout = reservation.payout?.amount || 0;
                report.totalRevenue += payout;
                report.platformBreakdown['airbnb'] += payout;
                report.totalBookings++;
            }
        });

        report.averageBookingValue = report.totalBookings > 0 ? 
            report.totalRevenue / report.totalBookings : 0;

        res.json({
            success: true,
            data: report,
            period: `${year}-${month}`
        });

    } catch (error) {
        console.error('Revenue report error:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        success: true,
        message: 'HostEasePro API server is running',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

// Error handling middleware
app.use((error, req, res, next) => {
    console.error('Server error:', error);
    res.status(500).json({
        success: false,
        error: 'Internal server error',
        message: error.message
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 HostEasePro API server running on port ${PORT}`);
    console.log(`📊 API endpoints available at:`);
    console.log(`   - GET /api/health`);
    console.log(`   - GET /api/bookings/booking-com`);
    console.log(`   - GET /api/bookings/airbnb`);
    console.log(`   - GET /api/reports/revenue`);
    console.log(`🔧 Make sure to configure your .env file with API credentials`);
});

module.exports = app;