#!/bin/bash

# Nyx Training Property Management - Deployment Script
echo "🚀 Starting Nyx Training Property Management System Deployment"

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js from https://nodejs.org/"
    exit 1
fi

# Check if MongoDB is running
if ! pgrep -x "mongod" > /dev/null; then
    echo "⚠️  MongoDB is not running. Please start MongoDB service."
    echo "   On Windows: Run 'net start MongoDB' in administrator command prompt"
    echo "   On macOS: Run 'brew services start mongodb/brew/mongodb-community'"
    echo "   On Linux: Run 'sudo systemctl start mongod'"
fi

echo "📦 Installing Backend Dependencies..."
cd backend
npm install

echo "🎨 Installing Frontend Dependencies..."
cd ../frontend
npm install

echo "⚙️  Setting up environment configuration..."
cd ../backend
if [ ! -f .env ]; then
    cp .env.example .env
    echo "✅ Created .env file from template"
    echo "⚠️  Please update the .env file with your actual configuration values"
else
    echo "✅ .env file already exists"
fi

echo "💾 Setting up database with initial data..."
node setup.js

echo ""
echo "🎉 Deployment Complete!"
echo ""
echo "📋 Next Steps:"
echo "1. Update backend/.env with your actual configuration"
echo "2. Start the backend server: cd backend && npm start"
echo "3. Start the frontend app: cd frontend && npm start"
echo ""
echo "🔐 Default Login Credentials:"
echo "   Admin: sn_apt_management@outlook.com / Speranta2015!"
echo "   Property Manager (Nina): nina@properties.com / nina123"
echo "   Customer: customer@example.com / customer123"
echo ""
echo "🌐 Application URLs:"
echo "   Frontend: http://localhost:3000"
echo "   Backend API: http://localhost:5000/api"
echo "   Health Check: http://localhost:5000/api/health"
echo ""
echo "📚 For more information, see README.md"