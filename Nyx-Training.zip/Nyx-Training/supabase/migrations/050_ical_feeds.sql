-- 050_ical_feeds.sql
-- Create iCal feeds table (referenced by existing 010_seed_ical_feeds.sql)
-- Ensures one feed per (org, property, platform). Includes RLS and updated_at trigger.

-- Safety: only create if not exists (idempotent for manual runs)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name = 'ical_feeds'
  ) THEN
    CREATE TABLE public.ical_feeds (
      id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
      org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
      property_id uuid NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
      platform text NOT NULL,
      feed_url text NOT NULL,
      is_active boolean NOT NULL DEFAULT true,
      last_import_at timestamptz,
      created_at timestamptz NOT NULL DEFAULT now(),
      updated_at timestamptz NOT NULL DEFAULT now()
    );

    -- Uniqueness constraint matching seed ON CONFLICT target
    CREATE UNIQUE INDEX ical_feeds_unique_platform_property
      ON public.ical_feeds (org_id, property_id, platform);

    -- Basic supporting index for active feeds lookups
    CREATE INDEX ical_feeds_active_idx ON public.ical_feeds (is_active);

    -- updated_at touch trigger
    CREATE OR REPLACE FUNCTION public.ical_feeds_updated_at()
    RETURNS trigger LANGUAGE plpgsql AS $$
    BEGIN
      NEW.updated_at := now();
      RETURN NEW;
    END;
    $$;

    CREATE TRIGGER ical_feeds_updated_at
    BEFORE UPDATE ON public.ical_feeds
    FOR EACH ROW EXECUTE FUNCTION public.ical_feeds_updated_at();

    -- Enable RLS
    ALTER TABLE public.ical_feeds ENABLE ROW LEVEL SECURITY;

    -- Policy: allow org members to read their feeds
    CREATE POLICY select_ical_feeds ON public.ical_feeds
    FOR SELECT USING (
      org_id = current_setting('request.jwt.claim.org_id', true)::uuid
    );

    -- Policy: allow org members (could refine to admins) to modify
    CREATE POLICY modify_ical_feeds ON public.ical_feeds
    FOR ALL USING (
      org_id = current_setting('request.jwt.claim.org_id', true)::uuid
    ) WITH CHECK (
      org_id = current_setting('request.jwt.claim.org_id', true)::uuid
    );
  END IF;
END
$$;

-- Verification helper comment:
-- SELECT platform, feed_url FROM public.ical_feeds;