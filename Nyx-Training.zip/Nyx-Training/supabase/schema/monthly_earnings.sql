-- monthly_earnings schema (snapshot table) + dynamic view
-- Provided inserts appear to be pre-aggregated cleaner earnings per month.
-- We'll create a table for storing snapshot rows and a view that dynamically recalculates from domestic_services.

DROP TABLE IF EXISTS public.monthly_earnings CASCADE;

CREATE TABLE public.monthly_earnings (
  month date NOT NULL,
  cleaner_id bigint NOT NULL,
  cleaner_name text,
  services_count int NOT NULL CHECK (services_count >= 0),
  total_earnings numeric NOT NULL DEFAULT 0,
  paid_services int NOT NULL DEFAULT 0 CHECK (paid_services >= 0),
  paid_amount numeric NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  user_id uuid NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  PRIMARY KEY (month, cleaner_id)
);

-- Updated timestamp trigger
CREATE OR REPLACE FUNCTION public.touch_monthly_earnings_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER monthly_earnings_updated_at
BEFORE UPDATE ON public.monthly_earnings
FOR EACH ROW EXECUTE FUNCTION public.touch_monthly_earnings_updated_at();

-- RLS policies
ALTER TABLE public.monthly_earnings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS monthly_earnings_select ON public.monthly_earnings;
CREATE POLICY monthly_earnings_select ON public.monthly_earnings FOR SELECT USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS monthly_earnings_insert ON public.monthly_earnings;
CREATE POLICY monthly_earnings_insert ON public.monthly_earnings FOR INSERT WITH CHECK (auth.role() = 'authenticated');
DROP POLICY IF EXISTS monthly_earnings_update ON public.monthly_earnings;
CREATE POLICY monthly_earnings_update ON public.monthly_earnings FOR UPDATE USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Dynamic view deriving live earnings from domestic_services (ignores snapshot table)
CREATE OR REPLACE VIEW public.domestic_monthly_earnings_live AS
SELECT date_trunc('month', ds.service_date)::date AS month,
       ds.cleaner_id,
       max(dsd.cleaner_name) AS cleaner_name,
       COUNT(*) AS services_count,
       SUM(ds.amount) AS total_earnings,
       SUM(CASE WHEN ds.payment_status='paid' THEN 1 ELSE 0 END) AS paid_services,
       SUM(CASE WHEN ds.payment_status='paid' THEN ds.amount ELSE 0 END) AS paid_amount
FROM public.domestic_services ds
LEFT JOIN public.domestic_services_detailed dsd ON ds.id = dsd.id
GROUP BY 1,2
ORDER BY month DESC, cleaner_id;

-- Index for potential cleaner/month queries
CREATE INDEX monthly_earnings_month_cleaner_idx ON public.monthly_earnings (month, cleaner_id);
