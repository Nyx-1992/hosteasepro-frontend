-- RLS helper functions for multi-tenant access
-- Provides defensive fallbacks if user_profiles table not yet created (returns NULL / FALSE instead of error).

CREATE OR REPLACE FUNCTION public.current_user_id()
RETURNS uuid LANGUAGE sql STABLE AS $$ SELECT auth.uid() $$;

CREATE OR REPLACE FUNCTION public.current_org_id()
RETURNS uuid LANGUAGE plpgsql STABLE AS $$
DECLARE v_org uuid;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='user_profiles'
  ) THEN
    RETURN NULL; -- user_profiles not ready; caller should handle NULL
  END IF;
  SELECT org_id INTO v_org FROM public.user_profiles WHERE user_id = auth.uid() LIMIT 1;
  RETURN v_org;
END;$$;

-- Check if user is org admin; returns FALSE if user_profiles table not yet present
CREATE OR REPLACE FUNCTION public.is_org_admin(org uuid)
RETURNS boolean LANGUAGE plpgsql STABLE AS $$
DECLARE v_exists boolean;
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='user_profiles'
  ) THEN
    RETURN FALSE;
  END IF;
  SELECT EXISTS (
    SELECT 1 FROM public.user_profiles p
    WHERE p.user_id = auth.uid() AND p.org_id = org AND p.role IN ('owner','admin')
  ) INTO v_exists;
  RETURN COALESCE(v_exists, FALSE);
END;$$;
