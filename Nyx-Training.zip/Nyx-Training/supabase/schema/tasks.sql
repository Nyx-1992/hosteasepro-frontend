-- tasks: operational tasks (cleaning, maintenance, admin) with workflow
DROP TABLE IF EXISTS public.tasks CASCADE;
CREATE TABLE public.tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  property_id uuid REFERENCES public.properties(id) ON DELETE SET NULL,
  booking_id bigint REFERENCES public.bookings(id) ON DELETE SET NULL, -- align with bookings.id (bigint)
  title text NOT NULL,
  description text,
  task_date date NOT NULL DEFAULT CURRENT_DATE,
  due_at timestamptz,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','in_progress','completed','cancelled')),
  type text NOT NULL DEFAULT 'cleaning' CHECK (type IN ('cleaning','maintenance','admin','other')),
  priority text NOT NULL DEFAULT 'normal' CHECK (priority IN ('low','normal','high','urgent')),
  assigned_user_id uuid REFERENCES public.user_profiles(user_id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE OR REPLACE FUNCTION public.touch_tasks_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER tasks_updated_at BEFORE UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.touch_tasks_updated_at();

-- Indexes
CREATE INDEX IF NOT EXISTS tasks_org_id_idx ON public.tasks(org_id);
CREATE INDEX IF NOT EXISTS tasks_status_idx ON public.tasks(status);
CREATE INDEX IF NOT EXISTS tasks_task_date_idx ON public.tasks(task_date);
CREATE INDEX IF NOT EXISTS tasks_assigned_user_idx ON public.tasks(assigned_user_id);

ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tasks_select ON public.tasks;
CREATE POLICY tasks_select ON public.tasks FOR SELECT USING (
  auth.role() = 'authenticated' AND org_id = public.current_org_id()
);
DROP POLICY IF EXISTS tasks_modify ON public.tasks;
CREATE POLICY tasks_modify ON public.tasks FOR ALL USING (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
) WITH CHECK (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
);
