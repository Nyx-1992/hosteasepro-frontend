-- migration_backfill_bookings_properties.sql
-- Purpose: Map legacy bookings.property_name to properties.id, assign org_id, and populate booking_checklists + link domestic services.
-- Run in Supabase SQL editor AFTER organizations & properties tables exist and before dropping any legacy columns.

-- 1. Determine target org (choose first created org as default tenant) ---------------------------------
-- Pre-checks: ensure required base tables exist; fail fast with clear message
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='organizations') THEN
    RAISE EXCEPTION 'Missing table public.organizations. Run organizations.sql before this migration.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='properties') THEN
    RAISE EXCEPTION 'Missing table public.properties. Run properties.sql before this migration.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='booking_checklists') THEN
    RAISE EXCEPTION 'Missing table public.booking_checklists. Run booking_checklists.sql before this migration.';
  END IF;
END $$;

DO $$ DECLARE v_org uuid; BEGIN
  SELECT id INTO v_org FROM public.organizations ORDER BY created_at LIMIT 1;
  IF v_org IS NULL THEN
    INSERT INTO public.organizations (name,status) VALUES ('Default Organization','active') RETURNING id INTO v_org;
  END IF;

  -- 2. Insert missing properties for each distinct property_name in bookings ---------------------------
  INSERT INTO public.properties (id, org_id, name, code, status)
  SELECT gen_random_uuid(), v_org, b.property_name, LEFT(b.property_name, 12), 'active'
  FROM public.bookings b
  LEFT JOIN public.properties p ON p.name = b.property_name AND p.org_id = v_org
  WHERE p.id IS NULL AND b.property_name IS NOT NULL AND b.property_name <> ''
  GROUP BY b.property_name;

  -- 3. Backfill org_id & property_id in bookings ------------------------------------------------------
  UPDATE public.bookings b
  SET org_id = v_org
  WHERE b.org_id IS NULL;

  UPDATE public.bookings b
  SET property_id = p.id
  FROM public.properties p
  WHERE b.property_id IS NULL
    AND p.org_id = v_org
    AND p.name = b.property_name;

  -- 4. Initialize booking_checklists rows for existing bookings ---------------------------------------
  INSERT INTO public.booking_checklists (booking_id, org_id, property_id)
  SELECT b.id, b.org_id, b.property_id
  FROM public.bookings b
  LEFT JOIN public.booking_checklists bc ON bc.booking_id = b.id
  WHERE bc.booking_id IS NULL;

  -- 5. Link domestic_services to bookings when service_date matches check_out date --------------------
  -- 5. Link domestic_services to bookings when service_date matches check_out date --------------------
  -- Guard if domestic_services table not yet migrated
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='domestic_services') THEN
    UPDATE public.domestic_services ds
    SET booking_id = b.id,
        org_id = b.org_id,
        property_id = b.property_id
    FROM public.bookings b
    WHERE ds.booking_id IS NULL
      AND ds.service_date = (b.check_out AT TIME ZONE 'UTC')::date
      AND b.property_id IS NOT NULL;
  END IF;
END $$;

-- Verification queries (optional):
-- SELECT COUNT(*) AS bookings_without_property FROM public.bookings WHERE property_id IS NULL;
-- SELECT COUNT(*) AS bookings_without_org FROM public.bookings WHERE org_id IS NULL;
-- SELECT * FROM public.booking_checklists LIMIT 10;
-- SELECT * FROM public.domestic_services WHERE booking_id IS NOT NULL LIMIT 10;
