-- upcoming_bookings_view: next 60 days of non-cancelled bookings per org
CREATE OR REPLACE VIEW public.upcoming_bookings AS
SELECT b.id,
       b.org_id,
       b.property_id,
       COALESCE(p.name, b.property_name) AS property_name,
       b.platform,
       b.check_in,
       b.check_out,
       b.check_in_date,
       b.check_out_date,
       b.nights,
       b.status,
       b.number_of_guests,
       b.guest_name,
       b.total_amount,
       b.currency
FROM public.bookings b
LEFT JOIN public.properties p ON p.id = b.property_id
WHERE b.status <> 'cancelled'
  AND b.check_in < (now() + interval '60 days')
  AND b.check_out >= current_date
  AND (b.org_id = public.current_org_id())
ORDER BY b.check_in;
