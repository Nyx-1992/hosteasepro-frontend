-- financial_transactions: income & expenses tied to bookings/properties
DROP TABLE IF EXISTS public.financial_transactions CASCADE;
-- Dependency guards (organizations, properties, bookings, contacts) to prevent cryptic FK errors
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='organizations') THEN
    RAISE EXCEPTION 'Missing table public.organizations. Run organizations.sql before financial_transactions.sql';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='properties') THEN
    RAISE EXCEPTION 'Missing table public.properties. Run properties.sql before financial_transactions.sql';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='bookings') THEN
    RAISE EXCEPTION 'Missing table public.bookings. Run bookings_clean.sql or bookings.sql before financial_transactions.sql';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='contacts') THEN
    RAISE EXCEPTION 'Missing table public.contacts. Run contacts.sql before financial_transactions.sql';
  END IF;
END $$;
CREATE TABLE public.financial_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  property_id uuid REFERENCES public.properties(id) ON DELETE SET NULL,
  booking_id bigint REFERENCES public.bookings(id) ON DELETE SET NULL, -- align with bookings.id (bigint)
  contact_id uuid REFERENCES public.contacts(id) ON DELETE SET NULL,
  txn_date date NOT NULL DEFAULT CURRENT_DATE,
  amount numeric(12,2) NOT NULL CHECK (amount <> 0), -- positive income, negative expense
  currency text NOT NULL DEFAULT 'EUR',
  direction text NOT NULL CHECK (direction IN ('income','expense')),
  method text CHECK (method IN ('bank_transfer','cash','card','online','other')),
  category text NOT NULL CHECK (category IN (
    'accommodation','cleaning_fee','service_fee','commission','maintenance','utilities','supplies','tax','other'
  )),
  description text,
  notes text,
  external_ref text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  -- Denormalized search text
  search_text text GENERATED ALWAYS AS (
    lower(coalesce(description,'') || ' ' || coalesce(notes,'') || ' ' || coalesce(category,'') || ' ' || coalesce(external_ref,''))
  ) STORED
);

CREATE OR REPLACE FUNCTION public.touch_financial_transactions_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER financial_transactions_updated_at BEFORE UPDATE ON public.financial_transactions FOR EACH ROW EXECUTE FUNCTION public.touch_financial_transactions_updated_at();

-- Indexes
CREATE INDEX IF NOT EXISTS financial_transactions_org_id_idx ON public.financial_transactions(org_id);
CREATE INDEX IF NOT EXISTS financial_transactions_property_id_idx ON public.financial_transactions(property_id);
CREATE INDEX IF NOT EXISTS financial_transactions_booking_id_idx ON public.financial_transactions(booking_id);
CREATE INDEX IF NOT EXISTS financial_transactions_txn_date_idx ON public.financial_transactions(txn_date);
CREATE INDEX IF NOT EXISTS financial_transactions_category_idx ON public.financial_transactions(category);
CREATE INDEX IF NOT EXISTS financial_transactions_search_idx ON public.financial_transactions USING GIN (to_tsvector('english', search_text));

ALTER TABLE public.financial_transactions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS financial_transactions_select ON public.financial_transactions;
CREATE POLICY financial_transactions_select ON public.financial_transactions FOR SELECT USING (
  auth.role() = 'authenticated' AND org_id = public.current_org_id()
);
DROP POLICY IF EXISTS financial_transactions_modify ON public.financial_transactions;
CREATE POLICY financial_transactions_modify ON public.financial_transactions FOR ALL USING (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
) WITH CHECK (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
);

-- Simple monthly aggregation view (live)
CREATE OR REPLACE VIEW public.financial_monthly_summary AS
SELECT org_id,
       date_trunc('month', txn_date) AS month,
       sum(CASE WHEN direction='income' THEN amount ELSE 0 END) AS total_income,
       sum(CASE WHEN direction='expense' THEN -amount ELSE 0 END) AS total_expense,
       sum(CASE WHEN direction='income' THEN amount ELSE -amount END) AS net_amount,
       COUNT(*) AS txn_count
FROM public.financial_transactions
GROUP BY org_id, date_trunc('month', txn_date);

-- Tenant-scoped convenience view (auto filters by current org; relies on RLS anyway but reduces client conditions)
CREATE OR REPLACE VIEW public.financial_monthly_summary_current_org AS
SELECT * FROM public.financial_monthly_summary
WHERE org_id = public.current_org_id();
