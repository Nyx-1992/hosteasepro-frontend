-- contacts: people/entities related to org (guests, owners, suppliers, cleaners)
DROP TABLE IF EXISTS public.contacts CASCADE;
CREATE TABLE public.contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  type text NOT NULL DEFAULT 'guest' CHECK (type IN ('guest','owner','supplier','cleaner','agent','other')),
  first_name text,
  last_name text,
  company text,
  email text,
  phone text,
  country text,
  notes text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  full_name text GENERATED ALWAYS AS (
    COALESCE(NULLIF(TRIM(first_name || ' ' || last_name),' '), company, email)
  ) STORED
);

-- Unique index enforcing org/email uniqueness only when email present (partial index)
CREATE UNIQUE INDEX IF NOT EXISTS contacts_org_email_unique
  ON public.contacts(org_id, email)
  WHERE email IS NOT NULL;

-- Auto-assignment trigger (single-org convenience). Remove once you manage multiple orgs.
CREATE OR REPLACE FUNCTION public.assign_contact_org()
RETURNS trigger AS $$
DECLARE v_org uuid; BEGIN
  IF NEW.org_id IS NULL THEN
    SELECT id INTO v_org FROM public.organizations ORDER BY created_at LIMIT 1;
    IF v_org IS NOT NULL THEN NEW.org_id := v_org; END IF;
  END IF;
  RETURN NEW;
END;$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS contacts_assign_org ON public.contacts;
CREATE TRIGGER contacts_assign_org
BEFORE INSERT ON public.contacts
FOR EACH ROW EXECUTE FUNCTION public.assign_contact_org();

CREATE OR REPLACE FUNCTION public.touch_contacts_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER contacts_updated_at BEFORE UPDATE ON public.contacts FOR EACH ROW EXECUTE FUNCTION public.touch_contacts_updated_at();

-- Basic indexes
CREATE INDEX IF NOT EXISTS contacts_org_id_idx ON public.contacts(org_id);
CREATE INDEX IF NOT EXISTS contacts_type_idx ON public.contacts(type);
CREATE INDEX IF NOT EXISTS contacts_active_idx ON public.contacts(is_active) WHERE is_active;

ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS contacts_select ON public.contacts;
CREATE POLICY contacts_select ON public.contacts FOR SELECT USING (
  auth.role() = 'authenticated' AND org_id = public.current_org_id()
);
DROP POLICY IF EXISTS contacts_modify ON public.contacts;
CREATE POLICY contacts_modify ON public.contacts FOR ALL USING (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
) WITH CHECK (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
);
