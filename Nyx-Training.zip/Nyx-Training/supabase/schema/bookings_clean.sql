-- Clean canonical bookings schema (fresh recreation)
-- Use this after backing up existing data if you want a blank reset.
-- Run in Supabase SQL editor.

DROP TABLE IF EXISTS public.bookings CASCADE;

-- Canonical multi-tenant bookings table (fresh recreation)
-- Adds org_id + property_id for tenant & property scoping while retaining property_name for legacy migration convenience.
CREATE TABLE public.bookings (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  property_id uuid NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  property_name text NOT NULL, -- legacy label; should match properties.name
  platform text NOT NULL,
  guest_first_name text,
  guest_last_name text,
  guest_name text, -- retained for legacy compatibility; populated by trigger
  guest_email text,
  guest_phone text,
  number_of_guests int DEFAULT 1 CHECK (number_of_guests > 0),
  check_in timestamptz NOT NULL,
  check_out timestamptz NOT NULL,
  nights int DEFAULT 1, -- maintained by nights sync trigger
  status text DEFAULT 'confirmed' CHECK (status IN ('pending','confirmed','checked-in','checked-out','cancelled','no-show')),
  base_amount numeric,
  cleaning_fee numeric DEFAULT 0,
  security_deposit numeric DEFAULT 0,
  taxes numeric DEFAULT 0,
  platform_fee numeric DEFAULT 0,
  total_amount numeric DEFAULT 0,
  currency text DEFAULT 'ZAR',
  payment_status text DEFAULT 'pending' CHECK (payment_status IN ('pending','partial','paid','refunded')),
  ical_event_id text,
  is_active boolean DEFAULT true,
  user_id uuid NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  -- Plain date columns (not generated) to avoid immutability errors; maintained by trigger below
  check_in_date date,
  check_out_date date
);

-- Normalization trigger (14:00 arrival, 10:00 departure when midnight provided)
CREATE OR REPLACE FUNCTION public.normalize_booking_times()
RETURNS trigger AS $$
DECLARE
  in_time time := (NEW.check_in AT TIME ZONE 'UTC')::time;
  out_time time := (NEW.check_out AT TIME ZONE 'UTC')::time;
BEGIN
  IF in_time = '00:00:00' THEN
    NEW.check_in := date_trunc('day', NEW.check_in) + INTERVAL '14 hours';
  END IF;
  IF out_time = '00:00:00' THEN
    NEW.check_out := date_trunc('day', NEW.check_out) + INTERVAL '10 hours';
  END IF;
  IF NEW.check_out <= NEW.check_in THEN
    RAISE EXCEPTION 'check_out (%) must be after check_in (%)', NEW.check_out, NEW.check_in;
  END IF;
  RETURN NEW;
END;$$ LANGUAGE plpgsql;

CREATE TRIGGER bookings_normalize_times
BEFORE INSERT OR UPDATE ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.normalize_booking_times();

-- Guest name sync trigger
CREATE OR REPLACE FUNCTION public.sync_guest_name()
RETURNS trigger AS $$
DECLARE combined text; BEGIN
  IF NEW.guest_name IS NOT NULL AND (NEW.guest_first_name IS NULL AND NEW.guest_last_name IS NULL) THEN
    NEW.guest_first_name := split_part(NEW.guest_name, ' ', 1);
    IF position(' ' IN NEW.guest_name) > 0 THEN
      NEW.guest_last_name := substr(NEW.guest_name, length(NEW.guest_first_name) + 2);
    END IF;
  END IF;
  IF NEW.guest_name IS NULL THEN
    combined := trim(coalesce(NEW.guest_first_name,'') || ' ' || coalesce(NEW.guest_last_name,''));
    IF combined <> '' THEN NEW.guest_name := combined; END IF;
  END IF;
  RETURN NEW; END;$$ LANGUAGE plpgsql;

CREATE TRIGGER bookings_sync_guest_name
BEFORE INSERT OR UPDATE ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.sync_guest_name();

-- Touch updated_at trigger
CREATE OR REPLACE FUNCTION public.touch_bookings_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER bookings_updated_at
BEFORE UPDATE ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.touch_bookings_updated_at();

-- Unique indexes
-- Uniqueness uses org_id + property_id for proper tenant isolation.
CREATE UNIQUE INDEX bookings_unique_span ON public.bookings (org_id, property_id, platform, check_in, check_out);
CREATE UNIQUE INDEX bookings_unique_date_span ON public.bookings (org_id, property_id, platform, check_in_date, check_out_date)
  WHERE status IN ('pending','confirmed','checked-in','checked-out');
-- Supporting btree indexes for common filtering
CREATE INDEX bookings_org_id_idx ON public.bookings(org_id);
CREATE INDEX bookings_property_id_idx ON public.bookings(property_id);
CREATE INDEX bookings_status_idx ON public.bookings(status);

-- Date sync trigger (ensures check_in_date / check_out_date always match timestamps)
CREATE OR REPLACE FUNCTION public.sync_booking_dates()
RETURNS trigger AS $$
BEGIN
  IF NEW.check_in IS NOT NULL THEN
    NEW.check_in_date := (NEW.check_in AT TIME ZONE 'UTC')::date;
  END IF;
  IF NEW.check_out IS NOT NULL THEN
    NEW.check_out_date := (NEW.check_out AT TIME ZONE 'UTC')::date;
  END IF;
  RETURN NEW;
END;$$ LANGUAGE plpgsql;

CREATE TRIGGER bookings_sync_dates
BEFORE INSERT OR UPDATE ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.sync_booking_dates();

-- Nights sync trigger (computes nights as whole calendar nights; enforces minimum 1)
CREATE OR REPLACE FUNCTION public.sync_booking_nights()
RETURNS trigger AS $$
DECLARE d1 date; d2 date; diff int; BEGIN
  d1 := (NEW.check_in AT TIME ZONE 'UTC')::date;
  d2 := (NEW.check_out AT TIME ZONE 'UTC')::date;
  diff := (d2 - d1);
  IF diff < 1 THEN diff := 1; END IF;
  NEW.nights := diff;
  RETURN NEW; END;$$ LANGUAGE plpgsql;

CREATE TRIGGER bookings_sync_nights
BEFORE INSERT OR UPDATE ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.sync_booking_nights();

-- Auto-create booking checklist row after a new booking is inserted (if missing)
CREATE OR REPLACE FUNCTION public.create_booking_checklist()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.booking_checklists (booking_id, org_id, property_id)
  VALUES (NEW.id, NEW.org_id, NEW.property_id)
  ON CONFLICT (booking_id) DO NOTHING;
  RETURN NEW;
END;$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS bookings_create_checklist ON public.bookings;
CREATE TRIGGER bookings_create_checklist
AFTER INSERT ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.create_booking_checklist();

-- Optional overlap exclusion (commented)
-- CREATE EXTENSION IF NOT EXISTS btree_gist;
-- ALTER TABLE public.bookings ADD COLUMN stay_range tsrange GENERATED ALWAYS AS (tsrange(check_in, check_out, '[)')) STORED;
-- ALTER TABLE public.bookings ADD CONSTRAINT bookings_no_overlap EXCLUDE USING gist (
--   property_name WITH =,
--   platform WITH =,
--   stay_range WITH &&
-- ) WHERE (status IN ('pending','confirmed','checked-in'));

-- RLS + policies
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS bookings_select ON public.bookings;
CREATE POLICY bookings_select ON public.bookings FOR SELECT USING (
  auth.role() = 'authenticated' AND org_id = public.current_org_id()
);
DROP POLICY IF EXISTS bookings_insert ON public.bookings;
CREATE POLICY bookings_insert ON public.bookings FOR INSERT WITH CHECK (
  auth.role() = 'authenticated' AND org_id = public.current_org_id()
);
DROP POLICY IF EXISTS bookings_update ON public.bookings;
CREATE POLICY bookings_update ON public.bookings FOR UPDATE USING (
  auth.role() = 'authenticated' AND org_id = public.current_org_id() AND public.is_org_admin(org_id)
) WITH CHECK (
  auth.role() = 'authenticated' AND org_id = public.current_org_id() AND public.is_org_admin(org_id)
);

-- Revenue view
CREATE OR REPLACE VIEW public.bookings_monthly_revenue AS
SELECT org_id,
       property_id,
       date_trunc('month', check_in) AS month,
       property_name,
       SUM(total_amount) AS revenue,
       COUNT(*) AS bookings
FROM public.bookings
WHERE status <> 'cancelled'
GROUP BY 1,2,3,4
ORDER BY 3 DESC;

-- Verification queries (run manually after execution):
-- SELECT COUNT(*) FROM public.bookings;
-- 
-- INSERT INTO public.bookings (property_name, platform, check_in, check_out, status, guest_first_name, guest_last_name)
-- VALUES ('Speranta','direct','2025-12-01','2025-12-05','confirmed','Alice','Koen') RETURNING id, check_in, check_out, nights, guest_name;
-- INSERT INTO public.bookings (property_name, platform, check_in, check_out, status, guest_name)
-- VALUES ('TV House','direct','2025-12-10','2025-12-12','confirmed','Bob Singh') RETURNING id, guest_first_name, guest_last_name, guest_name;