-- Seed data for domestic_services (idempotent)
-- Adapted from provided INSERT sample; uses ON CONFLICT DO NOTHING on (property_id, service_date, service_type, amount) as a pseudo-natural key.
-- If you later add a natural surrogate or unique constraint, adjust conflict target accordingly.

-- Use OVERRIDING SYSTEM VALUE to allow explicit identity ids (GENERATED ALWAYS)
INSERT INTO public.domestic_services (
  id, cleaner_id, property_id, service_date, service_type, amount, currency,
  payment_status, payment_date, payment_method, booking_id, notes, before_photos, after_photos
) OVERRIDING SYSTEM VALUE VALUES
  (1, 1, 1, '2025-10-08', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-08', 'ewallet', NULL, NULL, NULL, NULL),
  (2, 1, 1, '2025-10-13', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-13', 'ewallet', NULL, NULL, NULL, NULL),
  (3, 1, 1, '2025-10-20', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-20', 'ewallet', NULL, NULL, NULL, NULL),
  (4, 1, 1, '2025-10-28', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-28', 'ewallet', NULL, NULL, NULL, NULL),
  (5, 1, 1, '2025-11-03', 'cleaning', 350.00, 'ZAR', 'pending', NULL, 'ewallet', NULL, NULL, NULL, NULL),
  (6, 2, 2, '2025-09-03', 'cleaning', 350.00, 'ZAR', 'paid', '2025-09-03', 'bank_transfer', NULL, NULL, NULL, NULL),
  (7, 2, 2, '2025-09-10', 'cleaning', 350.00, 'ZAR', 'paid', '2025-09-10', 'bank_transfer', NULL, NULL, NULL, NULL),
  (8, 2, 2, '2025-09-15', 'cleaning', 350.00, 'ZAR', 'paid', '2025-09-15', 'bank_transfer', NULL, NULL, NULL, NULL),
  (9, 2, 2, '2025-10-05', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-05', 'bank_transfer', NULL, NULL, NULL, NULL),
  (10, 2, 2, '2025-10-15', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-15', 'bank_transfer', NULL, NULL, NULL, NULL),
  (11, 2, 2, '2025-10-21', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-21', 'bank_transfer', NULL, NULL, NULL, NULL),
  (12, 2, 2, '2025-10-29', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-29', 'bank_transfer', NULL, NULL, NULL, NULL),
  (13, 2, 2, '2025-11-04', 'cleaning', 350.00, 'ZAR', 'pending', NULL, 'bank_transfer', NULL, NULL, NULL, NULL),
  (14, 2, 2, '2025-11-12', 'cleaning', 350.00, 'ZAR', 'pending', NULL, 'bank_transfer', NULL, NULL, NULL, NULL)
ON CONFLICT (id) DO NOTHING;

-- Verification queries:
-- SELECT * FROM public.domestic_services ORDER BY service_date DESC;
-- SELECT * FROM public.domestic_monthly_cost ORDER BY month DESC;
