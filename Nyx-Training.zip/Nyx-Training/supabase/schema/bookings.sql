-- Supabase schema for bookings table and related objects
-- Run this in Supabase SQL editor for project: deigziteppzapshgotmu

-- 1. Table definition (adjust if already exists)
CREATE TABLE IF NOT EXISTS public.bookings (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  property_id uuid NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  property_name text, -- legacy label retained; should match properties.name eventually
  platform text NOT NULL, -- 'lekkeslaap','airbnb','booking.com','owner-block','direct'
  guest_first_name text,
  guest_last_name text,
  guest_email text,
  guest_phone text,
  number_of_guests int DEFAULT 1 CHECK (number_of_guests > 0),
  check_in timestamptz NOT NULL,
  check_out timestamptz NOT NULL,
  nights int GENERATED ALWAYS AS (GREATEST(1, (DATE_PART('day', check_out - check_in)))) STORED,
  status text DEFAULT 'confirmed' CHECK (status IN ('pending','confirmed','checked-in','checked-out','cancelled','no-show')),
  base_amount numeric,
  cleaning_fee numeric DEFAULT 0,
  security_deposit numeric DEFAULT 0,
  taxes numeric DEFAULT 0,
  platform_fee numeric DEFAULT 0,
  total_amount numeric DEFAULT 0,
  currency text DEFAULT 'ZAR',
  payment_status text DEFAULT 'pending' CHECK (payment_status IN ('pending','partial','paid','refunded')),
  ical_event_id text,
  is_active boolean DEFAULT true,
  user_id uuid NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- If bookings table already existed WITHOUT property_name, add it now (idempotent)
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS property_name text;
-- Ensure not null constraint only if you want to enforce; comment out if migrating gradually
DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name='bookings' AND column_name='property_name'
  ) THEN
    -- Optional: set any NULLs to placeholder before enforcing NOT NULL
    UPDATE public.bookings SET property_name = COALESCE(property_name,'UNKNOWN_PROPERTY') WHERE property_name IS NULL;
  END IF;
END $$;


-- === Legacy column migration block ===
-- If an older bookings table exists WITHOUT the new standardized columns, add them.
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS check_in timestamptz;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS check_out timestamptz;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS nights int;

-- If legacy columns exist (e.g. start_date / end_date), copy their data forward (adjust names if your legacy schema differs)
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='bookings' AND column_name='start_date') AND
     NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='bookings' AND column_name='check_in') THEN
     EXECUTE 'UPDATE public.bookings SET check_in = start_date WHERE check_in IS NULL';
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='bookings' AND column_name='end_date') AND
     NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name='bookings' AND column_name='check_out') THEN
     EXECUTE 'UPDATE public.bookings SET check_out = end_date WHERE check_out IS NULL';
  END IF;
END $$;

-- Backfill nights if missing
UPDATE public.bookings
SET nights = GREATEST(1, DATE_PART('day', check_out - check_in))
WHERE check_in IS NOT NULL AND check_out IS NOT NULL AND (nights IS NULL OR nights = 0);

-- Nights auto-update trigger (idempotent recreation)
CREATE OR REPLACE FUNCTION public.calc_nights()
RETURNS trigger AS $$
BEGIN
  IF NEW.check_in IS NOT NULL AND NEW.check_out IS NOT NULL THEN
    NEW.nights = GREATEST(1, DATE_PART('day', NEW.check_out - NEW.check_in));
  END IF;
  RETURN NEW;
END;$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS bookings_calc_nights ON public.bookings;
CREATE TRIGGER bookings_calc_nights
BEFORE INSERT OR UPDATE ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.calc_nights();

-- Auto-create booking checklist row after insert (legacy/migration aware: only if org_id/property_id present)
CREATE OR REPLACE FUNCTION public.create_booking_checklist_if_ready()
RETURNS trigger AS $$
BEGIN
  IF NEW.org_id IS NOT NULL AND NEW.property_id IS NOT NULL THEN
    INSERT INTO public.booking_checklists (booking_id, org_id, property_id)
    VALUES (NEW.id, NEW.org_id, NEW.property_id)
    ON CONFLICT (booking_id) DO NOTHING;
  END IF;
  RETURN NEW;
END;$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS bookings_create_checklist ON public.bookings;
CREATE TRIGGER bookings_create_checklist
AFTER INSERT ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.create_booking_checklist_if_ready();


-- 2. Update timestamp trigger
CREATE OR REPLACE FUNCTION public.touch_bookings_updated_at()
RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS bookings_updated_at ON public.bookings;
CREATE TRIGGER bookings_updated_at
BEFORE UPDATE ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.touch_bookings_updated_at();

-- 3. Unique index to prevent duplicates (same property / platform / span)
-- Replace span uniqueness with org/property scoping if new columns present.
-- Enforce NOT NULL before creating unique indexes (guard against legacy NULL rows)
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM public.bookings WHERE org_id IS NULL OR property_id IS NULL) THEN
    RAISE NOTICE 'Found legacy rows with NULL org_id/property_id. Unique index will treat NULLs as distinct allowing duplicates. Populate these values before relying on uniqueness.';
  END IF;
END $$;

DROP INDEX IF EXISTS bookings_unique_span;
CREATE UNIQUE INDEX IF NOT EXISTS bookings_unique_span
ON public.bookings (org_id, property_id, platform, check_in, check_out);

-- Optional: canonical date-span uniqueness (ignores time component) for active/non-cancelled bookings.
-- Run ONLY after check_in / check_out columns exist.
-- This blocks inserting the exact same date boundaries (regardless of 14:00 vs 15:00 differences).
-- Robust date-span uniqueness: expression on timestamptz -> date caused IMMUTABLE error.
-- Use generated stored date columns for safe indexing.
ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS check_in_date date GENERATED ALWAYS AS ((check_in AT TIME ZONE 'UTC')::date) STORED;
ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS check_out_date date GENERATED ALWAYS AS ((check_out AT TIME ZONE 'UTC')::date) STORED;

-- Drop any prior failed attempt
DROP INDEX IF EXISTS bookings_unique_date_span;
CREATE UNIQUE INDEX IF NOT EXISTS bookings_unique_date_span
ON public.bookings (org_id, property_id, platform, check_in_date, check_out_date)
WHERE status IN ('pending','confirmed','checked-in','checked-out');

-- Time normalization trigger: sets default arrival (14:00) and departure (10:00) if only a date (midnight) was supplied.
-- Safe to re-run; DROP TRIGGER removes any prior version.
CREATE OR REPLACE FUNCTION public.normalize_booking_times()
RETURNS trigger AS $$
DECLARE
  in_time time := (NEW.check_in AT TIME ZONE 'UTC')::time;
  out_time time := (NEW.check_out AT TIME ZONE 'UTC')::time;
BEGIN
  -- Apply defaults only when midnight (date-only semantics)
  IF in_time = '00:00:00' THEN
    NEW.check_in := date_trunc('day', NEW.check_in) + INTERVAL '14 hours';
  END IF;
  IF out_time = '00:00:00' THEN
    NEW.check_out := date_trunc('day', NEW.check_out) + INTERVAL '10 hours';
  END IF;

  -- Ensure chronological order (allow back-to-back nights but not inverted spans)
  IF NEW.check_out <= NEW.check_in THEN
    RAISE EXCEPTION 'check_out (%) must be after check_in (%)', NEW.check_out, NEW.check_in;
  END IF;
  RETURN NEW;
END;$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS bookings_normalize_times ON public.bookings;
CREATE TRIGGER bookings_normalize_times
BEFORE INSERT OR UPDATE ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.normalize_booking_times();

-- Auto-assignment trigger: allows inserting with only property_name (and optionally omitting org_id/property_id)
-- WARNING: Only suitable for single-org setup. If multiple orgs appear later, require explicit org_id/property_id.
CREATE OR REPLACE FUNCTION public.assign_booking_org_property()
RETURNS trigger AS $$
DECLARE v_org uuid; v_prop uuid; BEGIN
  -- Resolve org_id if NULL: pick first organization
  IF NEW.org_id IS NULL THEN
    SELECT id INTO v_org FROM public.organizations ORDER BY created_at LIMIT 1;
    IF v_org IS NOT NULL THEN NEW.org_id := v_org; END IF;
  END IF;
  -- Resolve property_id from property_name if NULL
  IF NEW.property_id IS NULL AND NEW.property_name IS NOT NULL AND NEW.org_id IS NOT NULL THEN
    SELECT id INTO v_prop FROM public.properties WHERE org_id = NEW.org_id AND name = NEW.property_name LIMIT 1;
    IF v_prop IS NULL THEN
      -- Create property on-the-fly
      INSERT INTO public.properties (id, org_id, name, status)
      VALUES (gen_random_uuid(), NEW.org_id, NEW.property_name, 'active') RETURNING id INTO v_prop;
    END IF;
    NEW.property_id := v_prop;
  END IF;
  RETURN NEW; END;$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS bookings_assign_org_property ON public.bookings;
CREATE TRIGGER bookings_assign_org_property
BEFORE INSERT ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.assign_booking_org_property();

-- =====================================================================
-- Legacy date columns (checkin_date / checkout_date) reconciliation
-- Legacy reconciliation block removed for clean install (no checkin_date/checkout_date legacy columns).

-- === Helper block for Strategy B (execute BEFORE dropping legacy columns) ===
-- 1. Rebuild nights column so it no longer depends on legacy columns (if it does in current live DB)
DO $$ BEGIN
  -- Detect if nights is a generated column referencing legacy fields
  IF EXISTS (
    SELECT 1 FROM pg_attribute a
    JOIN pg_class c ON a.attrelid = c.oid
    WHERE c.relname = 'bookings' AND a.attname = 'nights'
  ) THEN
    -- Instead of altering generated expression (not supported for reuse with ADD GENERATED),
    -- choose one of two strategies:
    -- STRATEGY 1 (recommended): keep existing generated formula as-is.
    -- STRATEGY 2: drop and recreate the column with new expression (lossless because regenerated).
    -- Uncomment STRATEGY 2 below if you want calendar date difference rather than time-diff.
    --
    -- STRATEGY 2 steps:
    -- ALTER TABLE public.bookings DROP COLUMN nights; -- will drop generated column
    -- ALTER TABLE public.bookings ADD COLUMN nights int GENERATED ALWAYS AS (
    --   GREATEST(1, (date_trunc('day', check_out)::date - date_trunc('day', check_in)::date))
    -- ) STORED;
    --
    -- If you already executed DROP COLUMN nights manually and re-added as plain int, backfill:
    -- UPDATE public.bookings SET nights = GREATEST(1, (date_trunc('day', check_out)::date - date_trunc('day', check_in)::date))
    -- WHERE nights IS NULL OR nights = 0;
  END IF;
END $$;

-- 2. Drop or replace dependent views referencing legacy columns (example: upcoming_bookings)
-- Save definition first if needed; then recreate using new generated columns.
DROP VIEW IF EXISTS public.upcoming_bookings;
CREATE OR REPLACE VIEW public.upcoming_bookings AS
SELECT id,
       property_name,
       check_in,
       check_out,
       check_in_date,
       check_out_date,
       status
FROM public.bookings
WHERE check_in >= now()
ORDER BY check_in ASC;

-- 3. After running this helper block you can safely execute Strategy B drops (uncomment there).

-- Guest name reconciliation: legacy schemas may have a NOT NULL guest_name column
-- while new design prefers guest_first_name / guest_last_name. This block makes it flexible.
-- 1. Ensure first/last name columns exist (idempotent for legacy tables lacking them)
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS guest_first_name text;
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS guest_last_name text;

-- 2. If guest_name exists and is NOT NULL, relax constraint so inserts without it can rely on trigger.
DO $$ BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name='bookings' AND column_name='guest_name'
  ) THEN
    -- Drop NOT NULL if currently enforced
    BEGIN
      ALTER TABLE public.bookings ALTER COLUMN guest_name DROP NOT NULL;
    EXCEPTION WHEN others THEN
      -- ignore if already nullable
    END;
  END IF;
END $$;

-- 3. Trigger to auto-populate guest_name from first/last or split guest_name if only that provided.
CREATE OR REPLACE FUNCTION public.sync_guest_name()
RETURNS trigger AS $$
DECLARE
  combined text;
BEGIN
  -- If legacy guest_name provided but first/last missing, attempt split on first space.
  IF NEW.guest_name IS NOT NULL AND (NEW.guest_first_name IS NULL AND NEW.guest_last_name IS NULL) THEN
    NEW.guest_first_name := split_part(NEW.guest_name, ' ', 1);
    IF position(' ' IN NEW.guest_name) > 0 THEN
      NEW.guest_last_name := substr(NEW.guest_name, length(NEW.guest_first_name) + 2);
    END IF;
  END IF;
  -- If first/last provided (or one of them) and guest_name NULL, join them.
  IF NEW.guest_name IS NULL THEN
    combined := trim(coalesce(NEW.guest_first_name,'') || ' ' || coalesce(NEW.guest_last_name,''));
    IF combined <> '' THEN
      NEW.guest_name := combined;
    END IF;
  END IF;
  RETURN NEW;
END;$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS bookings_sync_guest_name ON public.bookings;
CREATE TRIGGER bookings_sync_guest_name
BEFORE INSERT OR UPDATE ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.sync_guest_name();

-- OPTIONAL stronger integrity: prevent overlapping active bookings for same property & platform.
-- Uncomment if you want hard blocking of overlaps instead of just dedupe of identical spans.
-- Requires btree_gist extension (GiST support).
-- CREATE EXTENSION IF NOT EXISTS btree_gist;
-- ALTER TABLE public.bookings
--   ADD COLUMN IF NOT EXISTS stay_range tsrange
--   GENERATED ALWAYS AS (tsrange(check_in, check_out, '[)')) STORED;
-- ALTER TABLE public.bookings
--   ADD CONSTRAINT bookings_no_overlap EXCLUDE USING gist (
--      property_name WITH =,
--      platform WITH =,
--      stay_range WITH &&
--   ) WHERE (status IN ('pending','confirmed','checked-in')); -- Exclude cancelled/no-show

-- 4. Enable Row Level Security
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;

-- 5. Policies (broad authenticated access) - adjust if using per-user scoping
DROP POLICY IF EXISTS bookings_select ON public.bookings;
CREATE POLICY bookings_select ON public.bookings
FOR SELECT USING (auth.role() = 'authenticated' AND (org_id IS NULL OR org_id = public.current_org_id()));

DROP POLICY IF EXISTS bookings_insert ON public.bookings;
CREATE POLICY bookings_insert ON public.bookings
FOR INSERT WITH CHECK (auth.role() = 'authenticated' AND (org_id IS NULL OR org_id = public.current_org_id()));

DROP POLICY IF EXISTS bookings_update ON public.bookings;
CREATE POLICY bookings_update ON public.bookings
FOR UPDATE USING (auth.role() = 'authenticated' AND (org_id IS NULL OR org_id = public.current_org_id()) AND (org_id IS NULL OR public.is_org_admin(org_id)))
WITH CHECK (auth.role() = 'authenticated' AND (org_id IS NULL OR org_id = public.current_org_id()) AND (org_id IS NULL OR public.is_org_admin(org_id)));

-- Optional per-user restrictive variant (commented out)
-- CREATE POLICY own_rows_select ON public.bookings
-- FOR SELECT USING (user_id = auth.uid());

-- CREATE POLICY own_rows_modify ON public.bookings
-- FOR UPDATE USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- 6. Helpful view for monthly revenue summary
CREATE OR REPLACE VIEW public.bookings_monthly_revenue AS
SELECT org_id,
       property_id,
       date_trunc('month', check_in) AS month,
       property_name,
       SUM(total_amount) AS revenue,
       COUNT(*) AS bookings
FROM public.bookings
WHERE status <> 'cancelled'
GROUP BY 1,2,3,4
ORDER BY 3 DESC;

-- 7. Sample query to verify
-- SELECT * FROM public.bookings ORDER BY check_in DESC LIMIT 25;
