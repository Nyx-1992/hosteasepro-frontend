-- Sample seed data for empty bookings table
-- Run AFTER bookings_clean.sql in a fresh project to smoke-test triggers & indexes.
-- Safe to re-run; ON CONFLICT DO NOTHING prevents duplicates.

INSERT INTO public.bookings (
  property_name, platform, check_in, check_out, status, guest_first_name, guest_last_name,
  number_of_guests, base_amount, cleaning_fee, taxes, platform_fee, total_amount, currency, payment_status
) VALUES
  ('Speranta','direct','2025-12-01','2025-12-05','confirmed','Alice','Koen',2,1500,250,150,0,1900,'ZAR','paid'),
  ('Speranta','direct','2025-12-10','2025-12-12','confirmed','Bruno','Meyer',1,900,150,90,0,1140,'ZAR','pending'),
  ('TV House','airbnb','2025-12-03','2025-12-08','confirmed','Carla','Singh',4,4200,400,420,350,5370,'ZAR','partial'),
  ('TV House','direct','2025-12-15','2025-12-16','confirmed','Derek','Stone',2,700,0,70,0,770,'ZAR','paid'),
  ('Lakeside Cabin','direct','2025-12-20','2025-12-27','confirmed','Ella','James',3,6300,500,630,0,7430,'ZAR','paid')
ON CONFLICT (property_name, platform, check_in, check_out) DO NOTHING;

-- Verification queries:
-- SELECT id, property_name, check_in, check_out, nights, guest_name, total_amount FROM public.bookings ORDER BY check_in;
-- SELECT property_name, SUM(total_amount) FROM public.bookings GROUP BY property_name;
-- SELECT * FROM public.bookings_monthly_revenue;
