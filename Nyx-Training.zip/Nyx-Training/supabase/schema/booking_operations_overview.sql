-- booking_operations_overview.sql
-- Unified operational snapshot combining bookings, checklist status, and domestic service summary.
-- Filters by current_org_id implicit via RLS; explicit where clause added for clarity.

CREATE OR REPLACE VIEW public.booking_operations_overview AS
WITH ds_summary AS (
  SELECT b.id AS booking_id,
         COUNT(ds.id) AS domestic_services_count,
         MAX(ds.service_date) AS last_service_date,
         SUM(ds.amount) FILTER (WHERE ds.payment_status='paid') AS domestic_paid_total,
         SUM(ds.amount) AS domestic_total
  FROM public.bookings b
  LEFT JOIN public.domestic_services ds ON ds.booking_id = b.id
  GROUP BY b.id
)
SELECT b.id,
       b.org_id,
       b.property_id,
       COALESCE(p.name, b.property_name) AS property_name,
       b.platform,
       b.check_in,
       b.check_out,
       b.nights,
       b.status,
       b.total_amount,
       b.currency,
       bc.domestic_booked_at,
       bc.guest_contacted_at,
       bc.checked_in_at,
       bc.checked_out_at,
       bc.review_written_at,
       bc.follow_up_sent_at,
       (bc.domestic_booked_at IS NOT NULL) AS domestic_booked,
       (bc.guest_contacted_at IS NOT NULL) AS guest_contacted,
       (bc.checked_in_at IS NOT NULL) AS guest_checked_in,
       (bc.checked_out_at IS NOT NULL) AS guest_checked_out,
       (bc.review_written_at IS NOT NULL) AS review_written,
       (bc.follow_up_sent_at IS NOT NULL) AS follow_up_sent,
       ds.domestic_services_count,
       ds.last_service_date,
       ds.domestic_paid_total,
       ds.domestic_total,
       ROUND((
         (CASE WHEN bc.domestic_booked_at IS NOT NULL THEN 1 ELSE 0 END +
          CASE WHEN bc.guest_contacted_at IS NOT NULL THEN 1 ELSE 0 END +
          CASE WHEN bc.checked_in_at IS NOT NULL THEN 1 ELSE 0 END +
          CASE WHEN bc.checked_out_at IS NOT NULL THEN 1 ELSE 0 END +
          CASE WHEN bc.review_written_at IS NOT NULL THEN 1 ELSE 0 END +
          CASE WHEN bc.follow_up_sent_at IS NOT NULL THEN 1 ELSE 0 END)
        / 6.0 * 100)::numeric,0) AS checklist_progress_percent
FROM public.bookings b
LEFT JOIN public.properties p ON p.id = b.property_id
LEFT JOIN public.booking_checklists bc ON bc.booking_id = b.id
LEFT JOIN ds_summary ds ON ds.booking_id = b.id
WHERE b.org_id = public.current_org_id();
