-- Seed snapshot monthly_earnings rows (idempotent)
-- Uses provided sample data; ON CONFLICT (month, cleaner_id) DO NOTHING prevents duplicates.
-- Guard: create table if it was not created by monthly_earnings.sql yet (minimal definition; full version has triggers & RLS).
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema='public' AND table_name='monthly_earnings'
  ) THEN
    CREATE TABLE public.monthly_earnings (
      month date NOT NULL,
      cleaner_id bigint NOT NULL,
      cleaner_name text,
      services_count int NOT NULL DEFAULT 0,
      total_earnings numeric NOT NULL DEFAULT 0,
      paid_services int NOT NULL DEFAULT 0,
      paid_amount numeric NOT NULL DEFAULT 0,
      created_at timestamptz DEFAULT now(),
      updated_at timestamptz DEFAULT now(),
      PRIMARY KEY (month, cleaner_id)
    );
  END IF;
END$$;

INSERT INTO public.monthly_earnings (
  month, cleaner_id, cleaner_name, services_count, total_earnings, paid_services, paid_amount
) VALUES
  ('2025-09-01', 2, 'Patricia Mutizwa', 3, 1050.00, 3, 1050.00),
  ('2025-10-01', 2, 'Patricia Mutizwa', 4, 1400.00, 4, 1400.00),
  ('2025-10-01', 1, 'Spiwe Gwingwizha', 4, 1400.00, 4, 1400.00),
  ('2025-11-01', 2, 'Patricia Mutizwa', 2, 700.00, 0, 0),
  ('2025-11-01', 1, 'Spiwe Gwingwizha', 1, 350.00, 0, 0)
ON CONFLICT (month, cleaner_id) DO NOTHING;

-- Verification queries:
-- SELECT * FROM public.monthly_earnings ORDER BY month DESC, cleaner_id;
-- SELECT * FROM public.domestic_monthly_earnings_live ORDER BY month DESC, cleaner_id;
