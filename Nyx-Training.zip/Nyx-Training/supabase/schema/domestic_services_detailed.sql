-- domestic_services_detailed schema
-- Since you provided raw INSERT statements, we model this as a denormalized snapshot table.
-- Optionally replace later with a VIEW joining cleaners + properties base tables.

DROP TABLE IF EXISTS public.domestic_services_detailed CASCADE;

CREATE TABLE public.domestic_services_detailed (
  id bigint PRIMARY KEY REFERENCES public.domestic_services(id) ON DELETE CASCADE,
  cleaner_id bigint,
  property_id bigint,
  service_date date NOT NULL,
  service_type text NOT NULL CHECK (service_type IN ('cleaning','laundry','maintenance','other')),
  amount numeric NOT NULL CHECK (amount >= 0),
  currency text DEFAULT 'ZAR',
  payment_status text DEFAULT 'pending' CHECK (payment_status IN ('pending','paid','partial','refunded')),
  payment_date date,
  payment_method text,
  booking_id bigint NULL,
  notes text,
  before_photos jsonb,
  after_photos jsonb,
  cleaner_name text,
  cleaner_phone text,
  property_name text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  user_id uuid NULL REFERENCES auth.users(id) ON DELETE SET NULL
);

-- Updated timestamp trigger
CREATE OR REPLACE FUNCTION public.touch_domestic_detailed_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER domestic_detailed_updated_at
BEFORE UPDATE ON public.domestic_services_detailed
FOR EACH ROW EXECUTE FUNCTION public.touch_domestic_detailed_updated_at();

-- Indexes
CREATE INDEX domestic_services_detailed_date_idx ON public.domestic_services_detailed (service_date);
CREATE INDEX domestic_services_detailed_cleaner_idx ON public.domestic_services_detailed (cleaner_id, service_date);
CREATE INDEX domestic_services_detailed_property_idx ON public.domestic_services_detailed (property_id, service_date);

-- RLS Policies
ALTER TABLE public.domestic_services_detailed ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS domestic_detailed_select ON public.domestic_services_detailed;
CREATE POLICY domestic_detailed_select ON public.domestic_services_detailed FOR SELECT USING (auth.role() = 'authenticated');
DROP POLICY IF EXISTS domestic_detailed_insert ON public.domestic_services_detailed;
CREATE POLICY domestic_detailed_insert ON public.domestic_services_detailed FOR INSERT WITH CHECK (auth.role() = 'authenticated');
DROP POLICY IF EXISTS domestic_detailed_update ON public.domestic_services_detailed;
CREATE POLICY domestic_detailed_update ON public.domestic_services_detailed FOR UPDATE USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Optional dynamic VIEW alternative (commented placeholder)
-- CREATE OR REPLACE VIEW public.domestic_services_detailed_view AS
-- SELECT ds.*, c.name AS cleaner_name, c.phone AS cleaner_phone, p.name AS property_name
-- FROM public.domestic_services ds
-- LEFT JOIN public.cleaners c ON ds.cleaner_id = c.id
-- LEFT JOIN public.properties p ON ds.property_id = p.id;
