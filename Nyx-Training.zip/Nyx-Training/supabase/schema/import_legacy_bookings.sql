-- Legacy bookings import helper
-- Use this script AFTER running bookings_clean.sql in a fresh project.
-- Assumes you have exported legacy data to a staging table `legacy_bookings_raw` with columns:
--   property_name, platform, checkin_date, checkout_date, guest_name, guest_first_name, guest_last_name,
--   guests, base_amount, cleaning_fee, security_deposit, taxes, platform_fee, total_amount, currency,
--   status, payment_status, ical_event_id
-- If your export uses different column names, create a view or adjust the SELECT mapping below.

-- 1. Create staging table (example; skip if already created by CSV import)
-- DROP TABLE IF EXISTS public.legacy_bookings_raw;
-- CREATE TABLE public.legacy_bookings_raw (
--   property_name text,
--   platform text,
--   checkin_date date,
--   checkout_date date,
--   guest_name text,
--   guest_first_name text,
--   guest_last_name text,
--   guests int,
--   base_amount numeric,
--   cleaning_fee numeric,
--   security_deposit numeric,
--   taxes numeric,
--   platform_fee numeric,
--   total_amount numeric,
--   currency text,
--   status text,
--   payment_status text,
--   ical_event_id text
-- );

-- 2. Import CSV into legacy_bookings_raw using Supabase dashboard (Table editor > Import data)
-- 3. Run transformation + insert:
WITH transformed AS (
  SELECT
    property_name,
    COALESCE(platform,'direct') AS platform,
    -- Normalize times: 14:00 arrival, 10:00 departure
    (checkin_date::timestamptz + INTERVAL '14 hours') AS check_in,
    (checkout_date::timestamptz + INTERVAL '10 hours') AS check_out,
    guest_first_name,
    guest_last_name,
    guest_name,
    COALESCE(guests,1) AS number_of_guests,
    COALESCE(base_amount,0) AS base_amount,
    COALESCE(cleaning_fee,0) AS cleaning_fee,
    COALESCE(security_deposit,0) AS security_deposit,
    COALESCE(taxes,0) AS taxes,
    COALESCE(platform_fee,0) AS platform_fee,
    COALESCE(total_amount,0) AS total_amount,
    COALESCE(currency,'ZAR') AS currency,
    COALESCE(status,'confirmed') AS status,
    COALESCE(payment_status,'pending') AS payment_status,
    ical_event_id
  FROM public.legacy_bookings_raw l
  WHERE checkout_date IS NOT NULL AND checkin_date IS NOT NULL AND checkout_date > checkin_date
)
INSERT INTO public.bookings (
  property_name, platform, check_in, check_out, guest_first_name, guest_last_name, guest_name, number_of_guests,
  base_amount, cleaning_fee, security_deposit, taxes, platform_fee, total_amount, currency, status, payment_status, ical_event_id
)
SELECT * FROM transformed
ON CONFLICT (property_name, platform, check_in, check_out) DO NOTHING;

-- 4. Verification queries:
-- SELECT COUNT(*) AS imported_rows FROM public.bookings;
-- SELECT property_name, platform, min(check_in), max(check_out) FROM public.bookings GROUP BY 1,2 ORDER BY 1;
-- SELECT * FROM public.bookings ORDER BY created_at DESC LIMIT 20;

-- 5. Cleanup (optional after verifying):
-- DROP TABLE public.legacy_bookings_raw;
