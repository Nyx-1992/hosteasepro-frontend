-- iCal feeds table to store platform calendar URLs per property
-- WARNING: Contains sensitive URLs; ensure RLS restricts access to admin users only.

CREATE TABLE IF NOT EXISTS public.ical_feeds (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  property_id uuid NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  platform text NOT NULL CHECK (platform IN ('airbnb','booking','lekkeslaap','fewo','other')),
  feed_url text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  last_import_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(org_id, property_id, platform)
);

CREATE OR REPLACE FUNCTION public.touch_ical_feeds_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS ical_feeds_updated_at ON public.ical_feeds;
CREATE TRIGGER ical_feeds_updated_at BEFORE UPDATE ON public.ical_feeds FOR EACH ROW EXECUTE FUNCTION public.touch_ical_feeds_updated_at();

ALTER TABLE public.ical_feeds ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS ical_feeds_select ON public.ical_feeds;
CREATE POLICY ical_feeds_select ON public.ical_feeds
FOR SELECT USING (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
);
DROP POLICY IF EXISTS ical_feeds_modify ON public.ical_feeds;
CREATE POLICY ical_feeds_modify ON public.ical_feeds
FOR ALL USING (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
) WITH CHECK (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
);
