-- property_users: per-property role mapping (cleaners, managers, etc.)
DROP TABLE IF EXISTS public.property_users CASCADE;
CREATE TABLE public.property_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  property_id uuid NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.user_profiles(user_id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'member' CHECK (role IN ('manager','cleaner','maintenance','viewer')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(property_id, user_id, role)
);

CREATE OR REPLACE FUNCTION public.touch_property_users_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER property_users_updated_at BEFORE UPDATE ON public.property_users FOR EACH ROW EXECUTE FUNCTION public.touch_property_users_updated_at();

ALTER TABLE public.property_users ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS property_users_select ON public.property_users;
CREATE POLICY property_users_select ON public.property_users FOR SELECT USING (
  auth.role() = 'authenticated' AND property_id IN (
    SELECT p.id FROM public.properties p WHERE p.org_id = public.current_org_id()
  )
);
DROP POLICY IF EXISTS property_users_modify ON public.property_users;
CREATE POLICY property_users_modify ON public.property_users FOR ALL USING (
  auth.role() = 'authenticated' AND EXISTS (
    SELECT 1 FROM public.properties p
    JOIN public.user_profiles u ON u.org_id = p.org_id AND u.user_id = auth.uid()
    WHERE p.id = property_id AND public.is_org_admin(p.org_id)
  )
) WITH CHECK (
  auth.role() = 'authenticated' AND EXISTS (
    SELECT 1 FROM public.properties p
    JOIN public.user_profiles u ON u.org_id = p.org_id AND u.user_id = auth.uid()
    WHERE p.id = property_id AND public.is_org_admin(p.org_id)
  )
);
