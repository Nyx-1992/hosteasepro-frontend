-- Seed script for user_profiles roles
-- Run AFTER creating organizations and user_profiles tables and AFTER the users exist in auth.users.
-- Idempotent inserts for admin (sn_apt_management@outlook.com) and manager (vanwyk.nina@gmail.com).

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='user_profiles') THEN
    RAISE EXCEPTION 'Table public.user_profiles not found.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='organizations') THEN
    RAISE EXCEPTION 'Table public.organizations not found.';
  END IF;
END $$;

-- Resolve organization (assumes single org scenario)
WITH org AS (
  SELECT id FROM public.organizations WHERE name = 'S&N Apt Management' LIMIT 1
), admin_user AS (
  SELECT id FROM auth.users WHERE email = 'sn_apt_management@outlook.com'
), manager_user AS (
  SELECT id FROM auth.users WHERE email = 'vanwyk.nina@gmail.com'
)
-- Insert admin profile
INSERT INTO public.user_profiles (user_id, org_id, role)
SELECT admin_user.id, org.id, 'admin'
FROM org, admin_user
WHERE admin_user.id IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM public.user_profiles p WHERE p.user_id = admin_user.id AND p.org_id = org.id AND p.role = 'admin'
  );

-- Insert manager profile
INSERT INTO public.user_profiles (user_id, org_id, role)
SELECT manager_user.id, org.id, 'manager'
FROM org, manager_user
WHERE manager_user.id IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM public.user_profiles p WHERE p.user_id = manager_user.id AND p.org_id = org.id AND p.role = 'manager'
  );

-- Idempotency note: Both INSERT statements only run if matching row absent.

-- Verification (uncomment to run after seeding):
-- SELECT u.email, p.role, p.org_id FROM public.user_profiles p JOIN auth.users u ON u.id = p.user_id ORDER BY u.email;

-- Verification
-- SELECT u.email, p.role, p.org_id FROM public.user_profiles p JOIN auth.users u ON u.id = p.user_id ORDER BY u.email;
