-- properties: represents rentable units under an organization
DROP TABLE IF EXISTS public.properties CASCADE;
CREATE TABLE public.properties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  name text NOT NULL,
  code text, -- short code for UI / calendar labels
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','archived')),
  type text CHECK (type IN ('apartment','house','studio','villa','cabin','other')),
  bedrooms int CHECK (bedrooms >= 0),
  bathrooms int CHECK (bathrooms >= 0),
  max_guests int CHECK (max_guests >= 0),
  timezone text DEFAULT 'UTC',
  address_line1 text,
  address_line2 text,
  city text,
  region text,
  country text,
  postal_code text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(org_id, name),
  UNIQUE(org_id, code)
);

CREATE OR REPLACE FUNCTION public.touch_properties_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER properties_updated_at BEFORE UPDATE ON public.properties FOR EACH ROW EXECUTE FUNCTION public.touch_properties_updated_at();

-- Indexes
CREATE INDEX IF NOT EXISTS properties_org_id_idx ON public.properties(org_id);
CREATE INDEX IF NOT EXISTS properties_status_idx ON public.properties(status) WHERE status='active';

ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS properties_select ON public.properties;
CREATE POLICY properties_select ON public.properties FOR SELECT USING (
  auth.role() = 'authenticated' AND org_id = public.current_org_id()
);
DROP POLICY IF EXISTS properties_modify ON public.properties;
CREATE POLICY properties_modify ON public.properties FOR ALL USING (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
) WITH CHECK (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
);
