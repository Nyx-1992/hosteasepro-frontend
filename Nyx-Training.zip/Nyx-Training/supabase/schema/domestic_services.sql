-- domestic_services schema (fresh project)
-- Run in Supabase SQL editor after bookings table exists.

DROP TABLE IF EXISTS public.domestic_services CASCADE;

CREATE TABLE public.domestic_services (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  org_id uuid REFERENCES public.organizations(id) ON DELETE CASCADE,
  property_id uuid REFERENCES public.properties(id) ON DELETE SET NULL,
  booking_id bigint NULL REFERENCES public.bookings(id) ON DELETE SET NULL, -- associated stay
  cleaner_id bigint,                 -- reference to cleaners table (optional, add FK later)
  service_date date NOT NULL,
  service_type text NOT NULL CHECK (service_type IN ('cleaning','laundry','maintenance','other')),
  amount numeric NOT NULL CHECK (amount >= 0),
  currency text DEFAULT 'ZAR',
  payment_status text DEFAULT 'pending' CHECK (payment_status IN ('pending','paid','partial','refunded')),
  payment_date date,
  payment_method text,               -- e.g. ewallet, bank_transfer, cash
  notes text,
  before_photos jsonb,               -- store array of URLs or metadata
  after_photos jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  user_id uuid NULL REFERENCES auth.users(id) ON DELETE SET NULL,
  -- Derived convenience flags for booking checklists (optional real-time indicators)
  is_associated_booking boolean GENERATED ALWAYS AS (booking_id IS NOT NULL) STORED
);

-- Touch updated_at trigger
CREATE OR REPLACE FUNCTION public.touch_domestic_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER domestic_updated_at
BEFORE UPDATE ON public.domestic_services
FOR EACH ROW EXECUTE FUNCTION public.touch_domestic_updated_at();

-- Basic index for fast date/property queries
CREATE INDEX domestic_services_property_date_idx ON public.domestic_services (property_id, service_date);
CREATE INDEX domestic_services_org_id_idx ON public.domestic_services (org_id);
CREATE INDEX domestic_services_booking_idx ON public.domestic_services (booking_id);
CREATE INDEX domestic_services_payment_status_idx ON public.domestic_services (payment_status);

-- RLS
ALTER TABLE public.domestic_services ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS domestic_select ON public.domestic_services;
CREATE POLICY domestic_select ON public.domestic_services FOR SELECT USING (
  auth.role() = 'authenticated' AND (org_id = public.current_org_id())
);
DROP POLICY IF EXISTS domestic_insert ON public.domestic_services;
CREATE POLICY domestic_insert ON public.domestic_services FOR INSERT WITH CHECK (
  auth.role() = 'authenticated' AND (org_id = public.current_org_id())
);
DROP POLICY IF EXISTS domestic_update ON public.domestic_services;
CREATE POLICY domestic_update ON public.domestic_services FOR UPDATE USING (
  auth.role() = 'authenticated' AND org_id = public.current_org_id() AND public.is_org_admin(org_id)
) WITH CHECK (
  auth.role() = 'authenticated' AND org_id = public.current_org_id() AND public.is_org_admin(org_id)
);

-- Monthly cost aggregation view
CREATE OR REPLACE VIEW public.domestic_monthly_cost AS
SELECT org_id,
       date_trunc('month', service_date)::date AS month,
       property_id,
       service_type,
       COUNT(*) AS services_count,
       SUM(amount) AS total_amount,
       SUM(CASE WHEN payment_status = 'paid' THEN amount ELSE 0 END) AS paid_amount,
       SUM(CASE WHEN payment_status = 'pending' THEN amount ELSE 0 END) AS pending_amount
FROM public.domestic_services
GROUP BY 1,2,3,4
ORDER BY 2 DESC, property_id;

-- Backfill booking linkage example (post-migration):
-- UPDATE public.domestic_services ds
-- SET booking_id = b.id
-- FROM public.bookings b
-- WHERE ds.booking_id IS NULL
--   AND ds.org_id = b.org_id
--   AND ds.property_id = b.property_id
--   AND ds.service_date = (b.check_out AT TIME ZONE 'UTC')::date
--   AND b.status IN ('confirmed','checked-in','checked-out');
