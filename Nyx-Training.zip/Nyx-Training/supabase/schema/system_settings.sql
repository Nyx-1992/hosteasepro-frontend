-- system_settings: org-scoped key/value configuration
DROP TABLE IF EXISTS public.system_settings CASCADE;
CREATE TABLE public.system_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  key text NOT NULL,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  description text,
  is_sensitive boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(org_id, key)
);

CREATE OR REPLACE FUNCTION public.touch_system_settings_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER system_settings_updated_at BEFORE UPDATE ON public.system_settings FOR EACH ROW EXECUTE FUNCTION public.touch_system_settings_updated_at();

ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS system_settings_select ON public.system_settings;
CREATE POLICY system_settings_select ON public.system_settings FOR SELECT USING (
  auth.role() = 'authenticated' AND org_id = public.current_org_id()
);
DROP POLICY IF EXISTS system_settings_modify ON public.system_settings;
CREATE POLICY system_settings_modify ON public.system_settings FOR ALL USING (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
) WITH CHECK (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
);
