-- knowledge_base: internal articles / SOPs / how-tos
DROP TABLE IF EXISTS public.knowledge_base CASCADE;
CREATE TABLE public.knowledge_base (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  title text NOT NULL,
  body_markdown text NOT NULL,
  tags text[] DEFAULT '{}',
  status text NOT NULL DEFAULT 'published' CHECK (status IN ('draft','published','archived')),
  author_user_id uuid REFERENCES public.user_profiles(user_id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  search_vector tsvector GENERATED ALWAYS AS (
    to_tsvector('english', coalesce(title,'') || ' ' || coalesce(body_markdown,''))
  ) STORED
);

CREATE OR REPLACE FUNCTION public.touch_knowledge_base_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER knowledge_base_updated_at BEFORE UPDATE ON public.knowledge_base FOR EACH ROW EXECUTE FUNCTION public.touch_knowledge_base_updated_at();

-- Indexes
CREATE INDEX IF NOT EXISTS knowledge_base_org_id_idx ON public.knowledge_base(org_id);
CREATE INDEX IF NOT EXISTS knowledge_base_status_idx ON public.knowledge_base(status);
CREATE INDEX IF NOT EXISTS knowledge_base_search_idx ON public.knowledge_base USING GIN (search_vector);

ALTER TABLE public.knowledge_base ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS knowledge_base_select ON public.knowledge_base;
CREATE POLICY knowledge_base_select ON public.knowledge_base FOR SELECT USING (
  auth.role() = 'authenticated' AND org_id = public.current_org_id()
);
DROP POLICY IF EXISTS knowledge_base_modify ON public.knowledge_base;
CREATE POLICY knowledge_base_modify ON public.knowledge_base FOR ALL USING (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
) WITH CHECK (
  auth.role() = 'authenticated' AND public.is_org_admin(org_id)
);
