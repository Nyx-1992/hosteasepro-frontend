-- booking_checklists: lifecycle checkpoints per booking
-- Each timestamp column indicates completion time of that step.
-- A NULL means not yet done. Derived booleans can be added in views.

DROP TABLE IF EXISTS public.booking_checklists CASCADE;
CREATE TABLE public.booking_checklists (
  booking_id bigint PRIMARY KEY REFERENCES public.bookings(id) ON DELETE CASCADE,
  org_id uuid NOT NULL REFERENCES public.organizations(id) ON DELETE CASCADE,
  property_id uuid NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
  domestic_booked_at timestamptz,
  guest_contacted_at timestamptz,
  checked_in_at timestamptz,
  checked_out_at timestamptz,
  review_written_at timestamptz,
  follow_up_sent_at timestamptz,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE OR REPLACE FUNCTION public.touch_booking_checklists_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER booking_checklists_updated_at BEFORE UPDATE ON public.booking_checklists FOR EACH ROW EXECUTE FUNCTION public.touch_booking_checklists_updated_at();

ALTER TABLE public.booking_checklists ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS booking_checklists_select ON public.booking_checklists;
CREATE POLICY booking_checklists_select ON public.booking_checklists FOR SELECT USING (
  auth.role() = 'authenticated' AND org_id = public.current_org_id()
);
DROP POLICY IF EXISTS booking_checklists_insert ON public.booking_checklists;
CREATE POLICY booking_checklists_insert ON public.booking_checklists FOR INSERT WITH CHECK (
  auth.role() = 'authenticated' AND org_id = public.current_org_id()
);
DROP POLICY IF EXISTS booking_checklists_update ON public.booking_checklists;
CREATE POLICY booking_checklists_update ON public.booking_checklists FOR UPDATE USING (
  auth.role() = 'authenticated' AND org_id = public.current_org_id() AND public.is_org_admin(org_id)
) WITH CHECK (
  auth.role() = 'authenticated' AND org_id = public.current_org_id() AND public.is_org_admin(org_id)
);

-- Progress view summarizing completion state
CREATE OR REPLACE VIEW public.booking_checklist_status AS
SELECT bc.booking_id,
       bc.org_id,
       bc.property_id,
       (bc.domestic_booked_at IS NOT NULL) AS domestic_booked,
       (bc.guest_contacted_at IS NOT NULL) AS guest_contacted,
       (bc.checked_in_at IS NOT NULL) AS guest_checked_in,
       (bc.checked_out_at IS NOT NULL) AS guest_checked_out,
       (bc.review_written_at IS NOT NULL) AS review_written,
       (bc.follow_up_sent_at IS NOT NULL) AS follow_up_sent,
       ROUND( (
         (CASE WHEN bc.domestic_booked_at IS NOT NULL THEN 1 ELSE 0 END +
          CASE WHEN bc.guest_contacted_at IS NOT NULL THEN 1 ELSE 0 END +
          CASE WHEN bc.checked_in_at IS NOT NULL THEN 1 ELSE 0 END +
          CASE WHEN bc.checked_out_at IS NOT NULL THEN 1 ELSE 0 END +
          CASE WHEN bc.review_written_at IS NOT NULL THEN 1 ELSE 0 END +
          CASE WHEN bc.follow_up_sent_at IS NOT NULL THEN 1 ELSE 0 END)
        / 6.0 * 100 )::numeric, 0) AS progress_percent
FROM public.booking_checklists bc;
