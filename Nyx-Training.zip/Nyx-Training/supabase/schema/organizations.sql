-- organizations: top-level tenant entities
DROP TABLE IF EXISTS public.organizations CASCADE;
CREATE TABLE public.organizations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  slug text GENERATED ALWAYS AS (lower(regexp_replace(name,'\s+','-','g'))) STORED UNIQUE,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE OR REPLACE FUNCTION public.touch_org_updated_at()
RETURNS trigger AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END;$$ LANGUAGE plpgsql;
CREATE TRIGGER org_updated_at BEFORE UPDATE ON public.organizations FOR EACH ROW EXECUTE FUNCTION public.touch_org_updated_at();

ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
-- Simple policy: any authenticated can read org list (tighten later)
DROP POLICY IF EXISTS org_select ON public.organizations;
CREATE POLICY org_select ON public.organizations FOR SELECT USING (auth.role() = 'authenticated');
-- Insert/update restricted: require authenticated (later restrict by admin flag)
DROP POLICY IF EXISTS org_write ON public.organizations;
CREATE POLICY org_write ON public.organizations FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');
