-- Seed script: initial organization and roles
-- Run in Supabase SQL editor AFTER creating the base tables: organizations, user_profiles.
-- Adjust if your actual table definitions differ.

-- 1. Ensure required tables exist (lightweight guards)
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='organizations') THEN
    RAISE EXCEPTION 'Table public.organizations not found. Create it before running this seed.';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='user_profiles') THEN
    RAISE EXCEPTION 'Table public.user_profiles not found. Create it before running this seed.';
  END IF;
END $$;

-- 2. Insert first organization (idempotent: skip if name already present)
WITH existing AS (
  SELECT id FROM public.organizations WHERE name = 'S&N Apt Management'
), ins AS (
  INSERT INTO public.organizations (id, name)
  SELECT gen_random_uuid(), 'S&N Apt Management'
  WHERE NOT EXISTS (SELECT 1 FROM existing)
  RETURNING id
)
SELECT COALESCE((SELECT id FROM existing),(SELECT id FROM ins)) AS organization_id;

-- 3. Helper function: has_org_role (if not already defined elsewhere)
CREATE OR REPLACE FUNCTION public.has_org_role(p_org uuid, p_roles text[])
RETURNS boolean LANGUAGE sql STABLE AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_profiles
    WHERE org_id = p_org AND user_id = auth.uid() AND role = ANY (p_roles)
  );
$$;

-- 4. (Optional) Adjust financial transaction RLS to allow only admin role to see them.
-- Uncomment if financial_transactions table exists and you want to restrict manager visibility.
-- DROP POLICY IF EXISTS financial_transactions_select ON public.financial_transactions;
-- CREATE POLICY financial_transactions_select ON public.financial_transactions
-- FOR SELECT USING (
--   auth.role() = 'authenticated' AND org_id = public.current_org_id() AND public.is_org_admin(org_id)
-- );

-- 5. Insert admin user profile for company email (requires auth.users row to exist)
-- Replace email if different. This will do nothing if already inserted.
WITH org AS (
  SELECT id FROM public.organizations WHERE name = 'S&N Apt Management'
), usr AS (
  SELECT id FROM auth.users WHERE email = 'sn_apt_management@outlook.com'
), existing AS (
  SELECT 1 FROM public.user_profiles p JOIN org ON p.org_id = org.id JOIN usr ON p.user_id = usr.id WHERE p.role='admin'
), ins AS (
  INSERT INTO public.user_profiles (user_id, org_id, role)
  SELECT usr.id, org.id, 'admin'
  FROM org, usr
  WHERE NOT EXISTS (SELECT 1 FROM existing) AND usr.id IS NOT NULL
  RETURNING user_id
)
SELECT COALESCE((SELECT user_id FROM ins),(SELECT id FROM usr)) AS admin_user_id;

-- 6. (Placeholder) Manager role for Nina - replace nina@example.com with actual email once user created.
-- 6. Manager role for Nina (idempotent). Requires Nina to exist in auth.users first.
WITH org AS (
  SELECT id FROM public.organizations WHERE name = 'S&N Apt Management'
), usr AS (
  SELECT id FROM auth.users WHERE email = 'vanwyk.nina@gmail.com'
), existing AS (
  SELECT 1 FROM public.user_profiles p JOIN org ON p.org_id = org.id JOIN usr ON p.user_id = usr.id WHERE p.role='manager'
), ins AS (
  INSERT INTO public.user_profiles (user_id, org_id, role)
  SELECT usr.id, org.id, 'manager'
  FROM org, usr
  WHERE NOT EXISTS (SELECT 1 FROM existing) AND usr.id IS NOT NULL
  RETURNING user_id
)
SELECT COALESCE((SELECT user_id FROM ins),(SELECT id FROM usr)) AS manager_user_id;

-- 7. Verification queries (run manually)
-- SELECT * FROM public.organizations;
-- SELECT * FROM public.user_profiles;
