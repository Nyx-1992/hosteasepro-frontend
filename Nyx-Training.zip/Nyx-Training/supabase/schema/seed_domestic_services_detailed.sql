-- Seed detailed domestic services rows (idempotent)
-- Requires domestic_services_detailed table and base domestic_services rows pre-inserted.
-- Uses ON CONFLICT (id) DO NOTHING to avoid duplication.

INSERT INTO public.domestic_services_detailed (
  id, cleaner_id, property_id, service_date, service_type, amount, currency, payment_status,
  payment_date, payment_method, booking_id, notes, before_photos, after_photos,
  cleaner_name, cleaner_phone, property_name
) VALUES
  (1, 1, 1, '2025-10-08', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-08', 'ewallet', NULL, NULL, NULL, NULL, 'Spiwe Gwingwizha', '+27 84 915 0894', 'Speranta Property'),
  (2, 1, 1, '2025-10-13', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-13', 'ewallet', NULL, NULL, NULL, NULL, 'Spiwe Gwingwizha', '+27 84 915 0894', 'Speranta Property'),
  (3, 1, 1, '2025-10-20', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-20', 'ewallet', NULL, NULL, NULL, NULL, 'Spiwe Gwingwizha', '+27 84 915 0894', 'Speranta Property'),
  (4, 1, 1, '2025-10-28', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-28', 'ewallet', NULL, NULL, NULL, NULL, 'Spiwe Gwingwizha', '+27 84 915 0894', 'Speranta Property'),
  (5, 1, 1, '2025-11-03', 'cleaning', 350.00, 'ZAR', 'pending', NULL, 'ewallet', NULL, NULL, NULL, NULL, 'Spiwe Gwingwizha', '+27 84 915 0894', 'Speranta Property'),
  (6, 2, 2, '2025-09-03', 'cleaning', 350.00, 'ZAR', 'paid', '2025-09-03', 'bank_transfer', NULL, NULL, NULL, NULL, 'Patricia Mutizwa', '+27 63 735 3892', 'TV House Property'),
  (7, 2, 2, '2025-09-10', 'cleaning', 350.00, 'ZAR', 'paid', '2025-09-10', 'bank_transfer', NULL, NULL, NULL, NULL, 'Patricia Mutizwa', '+27 63 735 3892', 'TV House Property'),
  (8, 2, 2, '2025-09-15', 'cleaning', 350.00, 'ZAR', 'paid', '2025-09-15', 'bank_transfer', NULL, NULL, NULL, NULL, 'Patricia Mutizwa', '+27 63 735 3892', 'TV House Property'),
  (9, 2, 2, '2025-10-05', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-05', 'bank_transfer', NULL, NULL, NULL, NULL, 'Patricia Mutizwa', '+27 63 735 3892', 'TV House Property'),
  (10, 2, 2, '2025-10-15', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-15', 'bank_transfer', NULL, NULL, NULL, NULL, 'Patricia Mutizwa', '+27 63 735 3892', 'TV House Property'),
  (11, 2, 2, '2025-10-21', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-21', 'bank_transfer', NULL, NULL, NULL, NULL, 'Patricia Mutizwa', '+27 63 735 3892', 'TV House Property'),
  (12, 2, 2, '2025-10-29', 'cleaning', 350.00, 'ZAR', 'paid', '2025-10-29', 'bank_transfer', NULL, NULL, NULL, NULL, 'Patricia Mutizwa', '+27 63 735 3892', 'TV House Property'),
  (13, 2, 2, '2025-11-04', 'cleaning', 350.00, 'ZAR', 'pending', NULL, 'bank_transfer', NULL, NULL, NULL, NULL, 'Patricia Mutizwa', '+27 63 735 3892', 'TV House Property'),
  (14, 2, 2, '2025-11-12', 'cleaning', 350.00, 'ZAR', 'pending', NULL, 'bank_transfer', NULL, NULL, NULL, NULL, 'Patricia Mutizwa', '+27 63 735 3892', 'TV House Property')
ON CONFLICT (id) DO NOTHING;

-- Verification:
-- SELECT id, cleaner_name, property_name, service_date, payment_status FROM public.domestic_services_detailed ORDER BY service_date DESC;
