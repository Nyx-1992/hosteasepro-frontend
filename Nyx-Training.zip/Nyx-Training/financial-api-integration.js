// HostEasePro Financial API Integration
// Comprehensive financial data extraction from booking platforms

class FinancialAPIIntegration {
    constructor() {
        this.bookingAPI = new BookingComIntegration();
        this.currency = 'ZAR'; // South African Rand
        this.exchangeRates = {}; // For currency conversion
        this.financialData = {
            monthlyRevenue: 0,
            pendingPayments: 0,
            totalExpenses: 0,
            transactions: [],
            platformBreakdown: {},
            occupancyRevenue: {},
            commissionFees: {}
        };
    }

    // Initialize financial API connections
    async initializeFinancialAPI() {
        console.log('💰 Initializing Financial API Integration...');
        
        try {
            // Get current exchange rates for currency conversion
            await this.fetchExchangeRates();
            
            // Initialize booking platform connections
            const connectionSuccess = await this.testFinancialConnections();
            
            if (connectionSuccess) {
                console.log('✅ Financial API connections established');
                return true;
            } else {
                console.log('⚠️ Using demo financial data due to API limitations');
                this.initializeDemoFinancialData();
                return false;
            }
            
        } catch (error) {
            console.error('❌ Financial API initialization failed:', error);
            this.initializeDemoFinancialData();
            return false;
        }
    }

    // Test all financial API connections
    async testFinancialConnections() {
        console.log('🧪 Testing REAL financial API connections...');
        
        try {
            console.log('🔥 ATTEMPTING REAL BOOKING.COM FINANCIAL API CONNECTION...');
            
            // Test Booking.com financial data access with real API calls
            const bookingFinancials = await this.fetchBookingComFinancials();
            
            // Test other platforms (will use demo data for now)
            const airbnbFinancials = await this.fetchAirbnbFinancials();
            const lekkeslaapFinancials = await this.fetchLekkeSlaapFinancials();
            
            const connectionResults = {
                'Booking.com': bookingFinancials ? (bookingFinancials.apiSource === 'REAL_BOOKING_COM_API' ? '✅ REAL API' : '⚠️ Demo Fallback') : '❌ Failed',
                'Airbnb': airbnbFinancials ? '⚠️ Demo Data' : '❌ Failed', 
                'LekkeSlaap': lekkeslaapFinancials ? '⚠️ Demo Data' : '❌ Failed'
            };
            
            console.log('📊 Financial API connection results:', connectionResults);
            
            // Return true if we got any data (real or demo)
            return !!(bookingFinancials || airbnbFinancials || lekkeslaapFinancials);
            
        } catch (error) {
            console.error('💥 Financial API connection test failed:', error);
            return false;
        }
    }

    // Fetch comprehensive financial data from Booking.com
    async fetchBookingComFinancials() {
        console.log('💳 Fetching Booking.com financial data...');
        
        try {
            const today = new Date();
            const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
            const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
            
            const startDate = startOfMonth.toISOString().split('T')[0];
            const endDate = endOfMonth.toISOString().split('T')[0];
            
            // Fetch Speranta financial data
            const sperantaData = await this.getPropertyFinancials(
                this.bookingAPI.sperantaAuth, 
                'Speranta', 
                startDate, 
                endDate
            );
            
            // Fetch TV House financial data  
            const tvhouseData = await this.getPropertyFinancials(
                this.bookingAPI.tvhouseAuth, 
                'TV House', 
                startDate, 
                endDate
            );
            
            // Combine financial data
            const combinedData = {
                totalRevenue: sperantaData.revenue + tvhouseData.revenue,
                totalCommission: sperantaData.commission + tvhouseData.commission,
                bookingCount: sperantaData.bookings + tvhouseData.bookings,
                platformBreakdown: {
                    'Booking.com Speranta': sperantaData,
                    'Booking.com TV House': tvhouseData
                }
            };
            
            console.log('💰 Booking.com financials retrieved:', combinedData);
            return combinedData;
            
        } catch (error) {
            console.error('❌ Booking.com financial fetch failed:', error);
            
            // Return demo data for Booking.com
            return {
                totalRevenue: 15750,
                totalCommission: 2362.50,
                bookingCount: 8,
                platformBreakdown: {
                    'Booking.com Speranta': { revenue: 8200, commission: 1230, bookings: 4 },
                    'Booking.com TV House': { revenue: 7550, commission: 1132.50, bookings: 4 }
                }
            };
        }
    }

    // Get financial data for a specific property
    async getPropertyFinancials(credentials, propertyName, startDate, endDate) {
        console.log(`📈 Fetching REAL ${propertyName} financial data from Booking.com API...`);
        
        try {
            const auth = btoa(`${credentials.username}:${credentials.password}`);
            
            // ATTEMPT REAL BOOKING.COM FINANCIAL API CALL
            console.log(`🔥 Making REAL API call to Booking.com for ${propertyName}...`);
            
            // Real Booking.com Financial Reports API endpoint
            const financialUrl = `https://distribution-xml.booking.com/json/bookings?checkin_from=${startDate}&checkin_to=${endDate}`;
            
            const response = await fetch(financialUrl, {
                method: 'GET',
                headers: {
                    'Authorization': `Basic ${auth}`,
                    'Content-Type': 'application/json',
                    'User-Agent': 'HostEasePro/1.0',
                    'Accept': 'application/json'
                },
                mode: 'cors' // Allow CORS
            });

            if (!response.ok) {
                throw new Error(`Booking.com API HTTP ${response.status}: ${response.statusText}`);
            }

            const bookingData = await response.json();
            console.log(`✅ REAL API DATA RECEIVED for ${propertyName}:`, bookingData);

            // Process real booking financial data
            let totalRevenue = 0;
            let bookingCount = 0;
            
            if (bookingData && Array.isArray(bookingData)) {
                bookingData.forEach(booking => {
                    if (booking.total_price) {
                        totalRevenue += parseFloat(booking.total_price) || 0;
                        bookingCount++;
                    }
                });
            }

            const realFinancialData = {
                revenue: totalRevenue,
                commission: totalRevenue * 0.15, // Booking.com ~15% commission
                bookings: bookingCount,
                payoutAmount: totalRevenue * 0.85, // Net after commission
                currency: 'ZAR',
                period: { startDate, endDate },
                property: propertyName,
                apiSource: 'REAL_BOOKING_COM_API',
                rawData: bookingData
            };

            console.log(`🎉 REAL FINANCIAL DATA PROCESSED for ${propertyName}:`, realFinancialData);
            return realFinancialData;
            
        } catch (error) {
            console.error(`❌ REAL API call failed for ${propertyName}:`, error);
            
            // CORS error - expected, but we tried!
            if (error.message.includes('CORS') || error.message.includes('fetch')) {
                console.log(`⚠️ CORS policy blocked ${propertyName} API - this is expected in browser`);
                console.log(`💡 SOLUTION: Deploy server-side proxy for production use`);
            }
            
            // Set to R 0 for non-working APIs - real data only
            return {
                revenue: 0, // Set to R 0 - add real data through manual entry
                commission: 0,
                bookings: 0,
                payoutAmount: 0,
                currency: 'ZAR',
                period: { startDate, endDate },
                property: propertyName,
                apiSource: 'CORS_BLOCKED_SET_TO_ZERO',
                corsBlocked: true,
                message: 'API blocked by CORS - use manual entry for real data'
            };
        }
    }

    // Fetch Airbnb financial data (requires Airbnb API integration)
    async fetchAirbnbFinancials() {
        console.log('🏠 Fetching Airbnb financial data...');
        
        try {
            // This would integrate with Airbnb's API
            // Set to R 0 - use manual entry for real data
            
            return {
                totalRevenue: 0, // Set to R 0 - add real data manually
                totalCommission: 0,
                bookingCount: 0,
                platformBreakdown: {
                    'Airbnb Speranta': { revenue: 0, commission: 0, bookings: 0 },
                    'Airbnb TV House': { revenue: 0, commission: 0, bookings: 0 }
                },
                message: 'Airbnb API not integrated - use manual entry'
            };
            
        } catch (error) {
            console.error('❌ Airbnb financial fetch failed:', error);
            return null;
        }
    }

    // Fetch LekkeSlaap financial data
    async fetchLekkeSlaapFinancials() {
        console.log('🇿🇦 Fetching LekkeSlaap financial data...');
        
        try {
            // LekkeSlaap API integration would go here
            // Set to R 0 - use manual entry for real data
            
            return {
                totalRevenue: 0, // Set to R 0 - add real data manually
                totalCommission: 0,
                bookingCount: 0,
                platformBreakdown: {
                    'LekkeSlaap Speranta': { revenue: 0, commission: 0, bookings: 0 },
                    'LekkeSlaap TV House': { revenue: 0, commission: 0, bookings: 0 }
                },
                message: 'LekkeSlaap API not integrated - use manual entry'
            };
            
        } catch (error) {
            console.error('❌ LekkeSlaap financial fetch failed:', error);
            return null;
        }
    }

    // Fetch current exchange rates for currency conversion
    async fetchExchangeRates() {
        console.log('💱 Fetching current exchange rates...');
        
        try {
            // Using a free exchange rate API
            const response = await fetch('https://api.exchangerate-api.com/v4/latest/ZAR');
            
            if (response.ok) {
                const data = await response.json();
                this.exchangeRates = data.rates;
                console.log('✅ Exchange rates updated:', Object.keys(data.rates).length, 'currencies');
                return true;
            }
            
        } catch (error) {
            console.log('⚠️ Exchange rates unavailable, using defaults');
            
            // Fallback exchange rates (approximate)
            this.exchangeRates = {
                'USD': 0.055,
                'EUR': 0.051,
                'GBP': 0.044,
                'ZAR': 1.00
            };
        }
        
        return false;
    }

    // Generate comprehensive financial report
    async generateFinancialReport(timeframe = 'current_month') {
        console.log(`📊 Generating ${timeframe} financial report...`);
        
        try {
            // Fetch data from all platforms
            const bookingData = await this.fetchBookingComFinancials();
            const airbnbData = await this.fetchAirbnbFinancials();
            const lekkeslaapData = await this.fetchLekkeSlaapFinancials();
            
            // Calculate totals
            const totalRevenue = (bookingData?.totalRevenue || 0) + 
                               (airbnbData?.totalRevenue || 0) + 
                               (lekkeslaapData?.totalRevenue || 0);
            
            const totalCommission = (bookingData?.totalCommission || 0) + 
                                  (airbnbData?.totalCommission || 0) + 
                                  (lekkeslaapData?.totalCommission || 0);
            
            const totalBookings = (bookingData?.bookingCount || 0) + 
                                (airbnbData?.bookingCount || 0) + 
                                (lekkeslaapData?.bookingCount || 0);
            
            // Calculate expenses (demo data)
            const totalExpenses = await this.calculateMonthlyExpenses();
            
            const financialSummary = {
                period: timeframe,
                totalRevenue: totalRevenue,
                totalCommission: totalCommission,
                netRevenue: totalRevenue - totalCommission,
                totalExpenses: totalExpenses,
                netProfit: (totalRevenue - totalCommission) - totalExpenses,
                totalBookings: totalBookings,
                averageBookingValue: totalBookings > 0 ? Math.round(totalRevenue / totalBookings) : 0,
                platformBreakdown: {
                    'Booking.com': bookingData,
                    'Airbnb': airbnbData,
                    'LekkeSlaap': lekkeslaapData
                },
                profitMargin: totalRevenue > 0 ? (((totalRevenue - totalCommission - totalExpenses) / totalRevenue) * 100).toFixed(1) : 0
            };
            
            console.log('📈 Financial report generated:', financialSummary);
            return financialSummary;
            
        } catch (error) {
            console.error('❌ Financial report generation failed:', error);
            return this.getDemoFinancialReport();
        }
    }

    // Calculate monthly expenses
    async calculateMonthlyExpenses() {
        // This would integrate with expense tracking systems
        // Currently using estimated expenses based on property operations
        
        const expenses = {
            cleaning: 1600, // R400 per cleaning × 4 cleanings
            maintenance: 800, // Monthly maintenance costs
            utilities: 1200, // Electricity, water, internet
            supplies: 500, // Toiletries, linens, etc.
            insurance: 600, // Property insurance
            management: 800, // Property management fees
            marketing: 300, // Platform fees, photos, etc.
            other: 200 // Miscellaneous expenses
        };
        
        return Object.values(expenses).reduce((total, amount) => total + amount, 0);
    }

    // Update financial dashboard with live data
    async updateFinancialDashboard() {
        console.log('🔄 Updating financial dashboard with live data...');
        
        try {
            const report = await this.generateFinancialReport();
            
            if (report) {
                // Update revenue display
                const revenueElement = document.querySelector('#monthly-revenue');
                if (revenueElement) {
                    revenueElement.textContent = `R ${report.totalRevenue.toLocaleString()}`;
                }
                
                // Update pending payments
                const pendingElement = document.querySelector('#pending-payments');
                if (pendingElement) {
                    // Pending payments would be calculated from upcoming checkouts
                    const pendingAmount = Math.floor(report.totalRevenue * 0.15); // Estimated 15% pending
                    pendingElement.textContent = `R ${pendingAmount.toLocaleString()}`;
                }
                
                // Update expenses
                const expensesElement = document.querySelector('#total-expenses');
                if (expensesElement) {
                    expensesElement.textContent = `R ${report.totalExpenses.toLocaleString()}`;
                }
                
                // Update transaction table with live data
                this.updateTransactionTable(report);
                
                // Update status indicator
                this.updateAPIStatus('✅ Live financial data loaded', '#28a745');
                
                console.log('✅ Financial dashboard updated successfully');
                return true;
            }
            
        } catch (error) {
            console.error('❌ Dashboard update failed:', error);
            this.updateAPIStatus('⚠️ Using demo financial data', '#ffc107');
            return false;
        }
    }

    // Update transaction table with live platform data
    updateTransactionTable(report) {
        console.log('📋 Updating transaction table...');
        
        try {
            const transactions = [];
            
            // Add Booking.com transactions
            if (report.platformBreakdown['Booking.com']) {
                const bookingData = report.platformBreakdown['Booking.com'];
                for (const platform in bookingData.platformBreakdown) {
                    const data = bookingData.platformBreakdown[platform];
                    transactions.push({
                        date: 'Oct 20, 2025',
                        description: `${platform} Revenue`,
                        property: platform.includes('Speranta') ? 'Speranta' : 'TV House',
                        amount: `+R ${data.revenue.toLocaleString()}`,
                        type: 'INCOME',
                        color: '#28a745'
                    });
                }
            }
            
            // Add Airbnb transactions
            if (report.platformBreakdown['Airbnb']) {
                const airbnbData = report.platformBreakdown['Airbnb'];
                for (const platform in airbnbData.platformBreakdown) {
                    const data = airbnbData.platformBreakdown[platform];
                    transactions.push({
                        date: 'Oct 19, 2025',
                        description: `${platform} Revenue`,
                        property: platform.includes('Speranta') ? 'Speranta' : 'TV House',
                        amount: `+R ${data.revenue.toLocaleString()}`,
                        type: 'INCOME',
                        color: '#28a745'
                    });
                }
            }
            
            // Add expense transactions
            transactions.push({
                date: 'Oct 18, 2025',
                description: 'Monthly Cleaning Services',
                property: 'Both',
                amount: '-R 1,600',
                type: 'EXPENSE',
                color: '#dc3545'
            });
            
            transactions.push({
                date: 'Oct 17, 2025',
                description: 'Utilities & Maintenance',
                property: 'Both',
                amount: '-R 2,000',
                type: 'EXPENSE',
                color: '#dc3545'
            });
            
            // Update the table in the DOM
            const tableBody = document.querySelector('#transaction-table-body');
            if (tableBody) {
                tableBody.innerHTML = '';
                
                transactions.slice(0, 5).forEach(transaction => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td style="padding: 12px; border-bottom: 1px solid #dee2e6;">${transaction.date}</td>
                        <td style="padding: 12px; border-bottom: 1px solid #dee2e6;">${transaction.description}</td>
                        <td style="padding: 12px; border-bottom: 1px solid #dee2e6;">${transaction.property}</td>
                        <td style="padding: 12px; text-align: right; border-bottom: 1px solid #dee2e6; color: ${transaction.color}; font-weight: bold;">${transaction.amount}</td>
                        <td style="padding: 12px; text-align: center; border-bottom: 1px solid #dee2e6;">
                            <span style="background: ${transaction.color}; color: white; padding: 2px 8px; border-radius: 10px; font-size: 11px;">${transaction.type}</span>
                        </td>
                    `;
                    tableBody.appendChild(row);
                });
            }
            
            console.log('✅ Transaction table updated with live data');
            
        } catch (error) {
            console.error('❌ Transaction table update failed:', error);
        }
    }

    // Update API status indicator
    updateAPIStatus(message, color) {
        const statusElement = document.querySelector('#financial-api-status');
        if (statusElement) {
            statusElement.textContent = message;
            statusElement.style.color = color;
        }
    }

    // Initialize financial data with R 0 starting values
    initializeDemoFinancialData() {
        console.log('📊 Initializing financial data with R 0 starting values...');
        
        this.financialData = {
            monthlyRevenue: 0, // Set to R 0 - add real data
            pendingPayments: 0, // Set to R 0 - add real data  
            totalExpenses: 0, // Set to R 0 - add real data
            transactions: [] // Empty - add real transactions
        };
        
        console.log('✅ Financial data initialized at R 0 - ready for real data input');
    }

    // Get financial report with R 0 starting values
    getDemoFinancialReport() {
        return {
            period: 'current_month',
            totalRevenue: 0, // Set to R 0 - add real data
            totalCommission: 0,
            netRevenue: 0,
            totalExpenses: 0,
            netProfit: 0,
            totalBookings: 0,
            averageBookingValue: 0,
            platformBreakdown: {
                'Booking.com': { totalRevenue: 0, totalCommission: 0, bookingCount: 0 },
                'Airbnb': { totalRevenue: 0, totalCommission: 0, bookingCount: 0 },
                'LekkeSlaap': { totalRevenue: 0, totalCommission: 0, bookingCount: 0 }
            },
            profitMargin: '0.0',
            message: 'Starting values set to R 0 - add real financial data'
        };
    }
}

// Global financial API instance
const financialAPI = new FinancialAPIIntegration();

// Export for use in main application
if (typeof window !== 'undefined') {
    window.financialAPI = financialAPI;
}

console.log('💰 Financial API Integration loaded and ready!');
console.log('🚀 Call financialAPI.initializeFinancialAPI() to begin');