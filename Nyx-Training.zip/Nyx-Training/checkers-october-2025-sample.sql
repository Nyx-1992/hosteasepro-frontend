-- ============================================================
-- SAMPLE CHECKERS SIXTYSIX SHOPPING DATA - OCTOBER 2025
-- TV House & Speranta Property Shopping Expenses
-- ============================================================

-- REAL OCTOBER 2025 CHECKERS SHOPPING DATA
-- From actual Checkers receipts provided

INSERT INTO shopping_expenses (
    property_id, 
    store_name, 
    transaction_date, 
    receipt_number, 
    total_amount, 
    payment_method, 
    category, 
    purpose, 
    items, 
    purchased_by,
    notes
) VALUES

-- October 28, 2025 - R 267.97
(2, 'Checkers Sixtysix', '2025-10-28', 'CHK-28102025', 267.97, 'card', 'groceries', 'Property supplies', 
 '[{"name":"Coca-Cola Original Soft Drink Can 300ml", "price":13.99}, {"name":"Baby Soft 2 Ply Fresh White Toilet Paper Roll 18 Pack", "price":169.99}, {"name":"Huletts White Sugar 2.5kg", "price":57.99}]', 
 'Nina', 'Basic property restocking'),

-- October 13, 2025 - R 360.96  
(1, 'Checkers Sixtysix', '2025-10-13', 'CHK-13102025', 360.96, 'card', 'cleaning_supplies', 'Laundry and cleaning supplies', 
 '[{"name":"Sta-soft Aromatherapy Dream Fabric Softener Refill 500ml", "price":48.99}, {"name":"OMO Auto Power Laundry Capsules 20 x 21ml", "price":146.99}, {"name":"Vanish Power 02 Pre-Wash Stain Remover 500ml", "price":94.99}, {"name":"Essentials Microfibre Kitchen Cloths 4-Pack Colour May Vary", "price":69.99}]', 
 'Nina', 'Comprehensive cleaning and laundry supplies'),

-- October 3, 2025 - R 354.93
(2, 'Checkers Sixtysix', '2025-10-03', 'CHK-03102025', 354.93, 'card', 'cleaning_supplies', 'Cleaning and household supplies', 
 '[{"name":"Coca-Cola Original Soft Drink Bottle 440ml", "price":13.99}, {"name":"Trudu Honey Mustard Flavoured Pretzels 30g", "price":11.98}, {"name":"Ariel Auto Liquid Detergent 2L", "price":169.99}, {"name":"Domestos Summer Fresh Multipurpose Thick Bleach 750ml", "price":35.99}, {"name":"Windolene Trigger Window Cleaner 750ml", "price":54.99}, {"name":"Good Stuff Bee Natural Wild Honey Vanilla Yoghurt Hand Wash Refill 1L", "price":84.99}]', 
 'Nina', 'Detergent and cleaning supplies restock'),

-- October 15, 2025 - R 332.95
(1, 'Checkers Sixtysix', '2025-10-15', 'CHK-15102025', 332.95, 'card', 'groceries', 'Food and household basics', 
 '[{"name":"PIEMANS Chicken Mushroom Pie (Domestic)", "price":26.99}, {"name":"Coca-Cola Original Soft Drink Can 300ml", "price":13.99}, {"name":"Baby Soft 2 Ply Fresh White Toilet Paper Roll 18 Pack", "price":169.99}, {"name":"Huletts White Sugar 2.5kg", "price":64.99}, {"name":"Sunlight Original Dishwashing Liquid 750ml", "price":37.99}]', 
 'Nina', 'Basic groceries and cleaning supplies');

-- Summary Comment
-- ============================================================
-- REAL OCTOBER 2025 SHOPPING SUMMARY (FROM ACTUAL RECEIPTS)
-- ============================================================
-- Oct 28: TV House - R 267.97 (Coke, toilet paper, sugar)
-- Oct 13: Speranta - R 360.96 (Laundry supplies, cleaning products)
-- Oct 3:  TV House - R 354.93 (Cleaning supplies, detergent, honey yogurt)  
-- Oct 15: Speranta - R 332.95 (Pie, Coke, toilet paper, sugar, dishwashing)
-- 
-- Total TV House Shopping: R 622.90 (2 trips)
-- Total Speranta Shopping: R 693.91 (2 trips)  
-- COMBINED TOTAL: R 1,316.81 (4 trips)
-- Average per trip: R 329.20
-- Primary Store: Checkers Sixtysix (100% of shopping)
-- ============================================================