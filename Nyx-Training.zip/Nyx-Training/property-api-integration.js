// HostEasePro API Integration Prototype
// This demonstrates how the API integration would work

class PropertyManagementAPI {
    constructor() {
        this.apiBaseUrl = 'http://localhost:3000/api'; // Your backend server
        this.mockMode = true; // Set to false when real APIs are configured
    }

    // Booking.com API Integration
    async fetchBookingComData(propertyId, startDate, endDate) {
        if (this.mockMode) {
            // Mock data for demonstration
            return {
                reservations: [
                    {
                        reservation_id: "BK123456789",
                        hotel_id: propertyId,
                        checkin: "2024-10-20",
                        checkout: "2024-10-23",
                        booker_details: {
                            firstname: "Sarah",
                            lastname: "Johnson", 
                            email: "sarah.johnson@email.com",
                            telephone: "+27823456789"
                        },
                        room_reservations: [{
                            no_of_guests: 2,
                            room_type: "Standard Room"
                        }],
                        total_price: 3450.00,
                        currency: "ZAR",
                        customer_comments: "Celebrating anniversary, would appreciate late checkout if possible",
                        status: "confirmed"
                    }
                ]
            };
        }

        try {
            const response = await fetch(`${this.apiBaseUrl}/bookings/booking-com?property=${propertyId}&start=${startDate}&end=${endDate}`);
            return await response.json();
        } catch (error) {
            console.error('Booking.com API Error:', error);
            return null;
        }
    }

    // Airbnb API Integration
    async fetchAirbnbData(hostId) {
        if (this.mockMode) {
            return {
                reservations: [
                    {
                        id: "HMABCD123456",
                        listing_id: hostId,
                        start_date: "2024-10-18",
                        end_date: "2024-10-20",
                        guest: {
                            first_name: "Michael",
                            // Note: Airbnb doesn't provide last names or direct contact info
                        },
                        guest_details: {
                            number_of_guests: 3
                        },
                        payout: {
                            amount: 2850.00,
                            currency: "ZAR",
                            host_fee: 142.50
                        },
                        special_requests: "Traveling with small dog, confirmed pet-friendly"
                    }
                ]
            };
        }

        try {
            const response = await fetch(`${this.apiBaseUrl}/bookings/airbnb?host=${hostId}`);
            return await response.json();
        } catch (error) {
            console.error('Airbnb API Error:', error);
            return null;
        }
    }

    // Enhanced guest data processing
    processBookingComGuest(reservation) {
        return {
            platform: 'booking',
            guestName: `${reservation.booker_details.firstname} ${reservation.booker_details.lastname}`,
            phone: reservation.booker_details.telephone,
            email: reservation.booker_details.email,
            guestCount: reservation.room_reservations[0].no_of_guests,
            specialRequests: reservation.customer_comments || 'None',
            bookingReference: reservation.reservation_id,
            totalAmount: `R${reservation.total_price.toLocaleString()}`,
            currency: reservation.currency,
            checkinDate: reservation.checkin,
            checkoutDate: reservation.checkout,
            status: reservation.status
        };
    }

    processAirbnbGuest(reservation) {
        return {
            platform: 'airbnb',
            guestName: `${reservation.guest.first_name} (Airbnb Guest)`,
            phone: 'Contact via Airbnb messaging',
            email: 'Contact via Airbnb messaging', 
            guestCount: reservation.guest_details.number_of_guests,
            specialRequests: reservation.special_requests || 'None',
            bookingReference: reservation.id,
            hostPayout: `R${reservation.payout.amount.toLocaleString()}`,
            platformFee: `R${reservation.payout.host_fee.toLocaleString()}`,
            checkinDate: reservation.start_date,
            checkoutDate: reservation.end_date,
            status: 'confirmed'
        };
    }

    // Integrate API data with existing iCal bookings
    async enhanceBookingData(icalBookings) {
        const enhancedBookings = [];

        for (const booking of icalBookings) {
            let enhancedBooking = {...booking};
            
            // Try to match with API data
            if (booking.platform === 'booking') {
                const apiData = await this.fetchBookingComData(
                    booking.property === 'Speranta' ? 'speranta_id' : 'tvhouse_id',
                    booking.start,
                    booking.end
                );
                
                if (apiData?.reservations?.length > 0) {
                    const matchedReservation = apiData.reservations.find(res => 
                        res.checkin === booking.start && res.checkout === booking.end
                    );
                    
                    if (matchedReservation) {
                        const guestData = this.processBookingComGuest(matchedReservation);
                        enhancedBooking = {...booking, ...guestData, apiEnhanced: true};
                    }
                }
            } else if (booking.platform === 'airbnb') {
                const apiData = await this.fetchAirbnbData(
                    booking.property === 'Speranta' ? 'speranta_airbnb_id' : 'tvhouse_airbnb_id'
                );
                
                if (apiData?.reservations?.length > 0) {
                    const matchedReservation = apiData.reservations.find(res => 
                        res.start_date === booking.start && res.end_date === booking.end
                    );
                    
                    if (matchedReservation) {
                        const guestData = this.processAirbnbGuest(matchedReservation);
                        enhancedBooking = {...booking, ...guestData, apiEnhanced: true};
                    }
                }
            }
            
            enhancedBookings.push(enhancedBooking);
        }

        return enhancedBookings;
    }

    // Revenue reporting from API data
    async generateRevenueReport() {
        const bookingComData = await this.fetchBookingComData('all', '2024-10-01', '2024-10-31');
        const airbnbData = await this.fetchAirbnbData('all');

        const report = {
            totalRevenue: 0,
            platformBreakdown: {},
            averageBookingValue: 0,
            totalBookings: 0
        };

        // Process Booking.com revenue
        if (bookingComData?.reservations) {
            bookingComData.reservations.forEach(res => {
                report.totalRevenue += res.total_price;
                report.platformBreakdown['booking.com'] = (report.platformBreakdown['booking.com'] || 0) + res.total_price;
                report.totalBookings++;
            });
        }

        // Process Airbnb revenue
        if (airbnbData?.reservations) {
            airbnbData.reservations.forEach(res => {
                report.totalRevenue += res.payout.amount;
                report.platformBreakdown['airbnb'] = (report.platformBreakdown['airbnb'] || 0) + res.payout.amount;
                report.totalBookings++;
            });
        }

        report.averageBookingValue = report.totalBookings > 0 ? report.totalRevenue / report.totalBookings : 0;

        return report;
    }
}

// Initialize API integration
const propertyAPI = new PropertyManagementAPI();

// Export for use in main application
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PropertyManagementAPI;
}