/**
 * ============================================================
 * SUPABASE DATABASE ABSTRACTION LAYER
 * S&N Apt Management - Property Management System
 * ============================================================
 * 
 * This file provides a clean interface for all database operations.
 * It abstracts Supabase calls and can be easily switched to other
 * databases if needed in the future.
 */

// Supabase Configuration
const SUPABASE_URL = 'https://deigziteppzapshgotmu.supabase.co'; // Replace with your actual URL
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRlaWd6aXRlcHB6YXBzaGdvdG11Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE4MTEyOTAsImV4cCI6MjA3NzM4NzI5MH0.e1VnlU8jFgfPmZJI4VTfWHrxktQyRfoYQ2FwEbQLY7g'; // Replace with your actual key

// Initialize Supabase client (will be loaded from CDN)
let supabase = null;

/**
 * Initialize Supabase connection
 * Call this before using any database functions
 */
async function initializeDatabase() {
    if (!window.supabase) {
        console.log('🔄 Loading Supabase from CDN...');
        await loadSupabaseFromCDN();
    }
    
    if (!supabase) {
        supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        console.log('✅ Database initialized successfully');
    }
    
    return supabase;
}

/**
 * Load Supabase library from CDN
 */
function loadSupabaseFromCDN() {
    return new Promise((resolve, reject) => {
        if (window.supabase) {
            resolve();
            return;
        }
        
        const script = document.createElement('script');
        script.src = 'https://unpkg.com/@supabase/supabase-js@2';
        script.onload = () => {
            console.log('📦 Supabase library loaded from CDN');
            resolve();
        };
        script.onerror = () => {
            console.error('❌ Failed to load Supabase library');
            reject(new Error('Failed to load Supabase library'));
        };
        document.head.appendChild(script);
    });
}

/**
 * ============================================================
 * DATABASE ABSTRACTION OBJECT
 * ============================================================
 */
const database = {
    
    // ============================================================
    // PROPERTIES OPERATIONS
    // ============================================================
    
    properties: {
        async getAll() {
            await initializeDatabase();
            const { data, error } = await supabase
                .from('properties')
                .select('*')
                .order('name');
            
            if (error) {
                console.error('❌ Error fetching properties:', error);
                throw error;
            }
            
            console.log(`📊 Fetched ${data.length} properties`);
            return data;
        },
        
        async getById(id) {
            await initializeDatabase();
            const { data, error } = await supabase
                .from('properties')
                .select('*')
                .eq('id', id)
                .single();
            
            if (error) throw error;
            return data;
        },
        
        async update(id, updates) {
            await initializeDatabase();
            const { data, error } = await supabase
                .from('properties')
                .update(updates)
                .eq('id', id)
                .select()
                .single();
            
            if (error) throw error;
            console.log('✅ Property updated:', data.name);
            return data;
        }
    },
    
    // ============================================================
    // BOOKINGS OPERATIONS
    // ============================================================
    
    bookings: {
        async getAll(filters = {}) {
            await initializeDatabase();
            let query = supabase
                .from('bookings')
                .select(`
                    *,
                    properties (
                        name,
                        address
                    )
                `)
                .order('checkin_date', { ascending: false });
            
            // Apply filters
            if (filters.property_id) {
                query = query.eq('property_id', filters.property_id);
            }
            
            if (filters.status) {
                query = query.eq('status', filters.status);
            }
            
            if (filters.from_date) {
                query = query.gte('checkin_date', filters.from_date);
            }
            
            if (filters.to_date) {
                query = query.lte('checkout_date', filters.to_date);
            }
            
            const { data, error } = await query;
            
            if (error) {
                console.error('❌ Error fetching bookings:', error);
                throw error;
            }
            
            console.log(`📅 Fetched ${data.length} bookings`);
            return data;
        },
        
        async getCurrent() {
            const today = new Date().toISOString().split('T')[0];
            return await this.getAll({
                from_date: today,
                status: 'confirmed'
            });
        },
        
        async getPast() {
            const today = new Date().toISOString().split('T')[0];
            await initializeDatabase();
            
            const { data, error } = await supabase
                .from('bookings')
                .select(`
                    *,
                    properties (
                        name,
                        address
                    )
                `)
                .lt('checkout_date', today)
                .order('checkout_date', { ascending: false });
            
            if (error) throw error;
            console.log(`📜 Fetched ${data.length} past bookings`);
            return data;
        },
        
        async add(booking) {
            await initializeDatabase();
            
            // Get property ID if property name is provided
            if (booking.property_name && !booking.property_id) {
                const properties = await database.properties.getAll();
                const property = properties.find(p => p.name.toLowerCase().includes(booking.property_name.toLowerCase()));
                if (property) {
                    booking.property_id = property.id;
                    delete booking.property_name;
                }
            }
            
            const { data, error } = await supabase
                .from('bookings')
                .insert([booking])
                .select(`
                    *,
                    properties (
                        name,
                        address
                    )
                `)
                .single();
            
            if (error) {
                console.error('❌ Error adding booking:', error);
                throw error;
            }
            
            console.log('✅ Booking added:', data.guest_name);
            return data;
        },
        
        async update(id, updates) {
            await initializeDatabase();
            const { data, error } = await supabase
                .from('bookings')
                .update(updates)
                .eq('id', id)
                .select(`
                    *,
                    properties (
                        name,
                        address
                    )
                `)
                .single();
            
            if (error) throw error;
            console.log('✅ Booking updated:', data.guest_name);
            return data;
        },
        
        async delete(id) {
            await initializeDatabase();
            const { error } = await supabase
                .from('bookings')
                .delete()
                .eq('id', id);
            
            if (error) throw error;
            console.log('🗑️ Booking deleted');
            return true;
        }
    },
    
    // ============================================================
    // CONTACTS OPERATIONS
    // ============================================================
    
    contacts: {
        async getAll(category = null) {
            await initializeDatabase();
            let query = supabase
                .from('contacts')
                .select('*')
                .eq('is_active', true)
                .order('category, name');
            
            if (category) {
                query = query.eq('category', category);
            }
            
            const { data, error } = await query;
            
            if (error) {
                console.error('❌ Error fetching contacts:', error);
                throw error;
            }
            
            console.log(`👥 Fetched ${data.length} contacts`);
            return data;
        },
        
        async getDomesticWorkers() {
            return await this.getAll('domestic');
        },
        
        async getTeamMembers() {
            return await this.getAll('team');
        },
        
        async add(contact) {
            await initializeDatabase();
            const { data, error } = await supabase
                .from('contacts')
                .insert([contact])
                .select()
                .single();
            
            if (error) {
                console.error('❌ Error adding contact:', error);
                throw error;
            }
            
            console.log('✅ Contact added:', data.name);
            return data;
        },
        
        async update(id, updates) {
            await initializeDatabase();
            const { data, error } = await supabase
                .from('contacts')
                .update(updates)
                .eq('id', id)
                .select()
                .single();
            
            if (error) throw error;
            console.log('✅ Contact updated:', data.name);
            return data;
        },

        // Update contact by name (for the UI edit function)
        async updateByName(name, updates) {
            await initializeDatabase();
            const { data, error } = await supabase
                .from('contacts')
                .update(updates)
                .eq('name', name)
                .select()
                .single();
            
            if (error) {
                console.error('❌ Error updating contact by name:', error);
                return { success: false, error: error.message };
            }
            
            console.log('✅ Contact updated by name:', data.name);
            return { success: true, data };
        }
    },
    
    // ============================================================
    // DOMESTIC SERVICES OPERATIONS
    // ============================================================
    
    domesticServices: {
        async getAll(filters = {}) {
            await initializeDatabase();
            let query = supabase
                .from('domestic_services_detailed')
                .select('*')
                .order('service_date', { ascending: false });
            
            if (filters.month && filters.year) {
                const startDate = `${filters.year}-${filters.month.toString().padStart(2, '0')}-01`;
                const endDate = new Date(filters.year, filters.month, 0).toISOString().split('T')[0];
                query = query.gte('service_date', startDate).lte('service_date', endDate);
            }
            
            if (filters.cleaner_id) {
                query = query.eq('cleaner_id', filters.cleaner_id);
            }
            
            const { data, error } = await query;
            
            if (error) {
                console.error('❌ Error fetching domestic services:', error);
                throw error;
            }
            
            console.log(`🧹 Fetched ${data.length} domestic services`);
            return data;
        },
        
        async getCurrentMonth() {
            const now = new Date();
            return await this.getAll({
                month: now.getMonth() + 1,
                year: now.getFullYear()
            });
        },
        
        async getMonthlyEarnings(month, year) {
            await initializeDatabase();
            const { data, error } = await supabase
                .from('monthly_earnings')
                .select('*')
                .eq('month', `${year}-${month.toString().padStart(2, '0')}-01`);
            
            if (error) throw error;
            return data;
        },
        
        async add(service) {
            await initializeDatabase();
            
            // Get cleaner ID if cleaner name is provided
            if (service.cleaner_name && !service.cleaner_id) {
                const contacts = await database.contacts.getDomesticWorkers();
                const cleaner = contacts.find(c => c.name.toLowerCase().includes(service.cleaner_name.toLowerCase()));
                if (cleaner) {
                    service.cleaner_id = cleaner.id;
                    delete service.cleaner_name;
                }
            }
            
            // Get property ID if property name is provided
            if (service.property_name && !service.property_id) {
                const properties = await database.properties.getAll();
                const property = properties.find(p => p.name.toLowerCase().includes(service.property_name.toLowerCase()));
                if (property) {
                    service.property_id = property.id;
                    delete service.property_name;
                }
            }
            
            const { data, error } = await supabase
                .from('domestic_services')
                .insert([service])
                .select()
                .single();
            
            if (error) {
                console.error('❌ Error adding domestic service:', error);
                throw error;
            }
            
            console.log('✅ Domestic service added');
            return data;
        },
        
        async updatePaymentStatus(id, status, paymentDate = null) {
            await initializeDatabase();
            const updates = { payment_status: status };
            if (paymentDate) updates.payment_date = paymentDate;
            
            const { data, error } = await supabase
                .from('domestic_services')
                .update(updates)
                .eq('id', id)
                .select()
                .single();
            
            if (error) throw error;
            console.log('💰 Payment status updated');
            return data;
        }
    },
    
    // ============================================================
    // TASKS OPERATIONS
    // ============================================================
    
    tasks: {
        async getAll(filters = {}) {
            await initializeDatabase();
            let query = supabase
                .from('tasks')
                .select(`
                    *,
                    properties (name),
                    contacts (name),
                    bookings (guest_name)
                `)
                .order('created_at', { ascending: false });
            
            if (filters.status) {
                query = query.eq('status', filters.status);
            }
            
            if (filters.priority) {
                query = query.eq('priority', filters.priority);
            }
            
            const { data, error } = await query;
            if (error) throw error;
            
            console.log(`📋 Fetched ${data.length} tasks`);
            return data;
        },
        
        async add(task) {
            await initializeDatabase();
            const { data, error } = await supabase
                .from('tasks')
                .insert([task])
                .select()
                .single();
            
            if (error) throw error;
            console.log('✅ Task added:', data.title);
            return data;
        },
        
        async updateStatus(id, status, completedDate = null) {
            await initializeDatabase();
            const updates = { status };
            if (status === 'completed' && completedDate) {
                updates.completed_date = completedDate;
            }
            
            const { data, error } = await supabase
                .from('tasks')
                .update(updates)
                .eq('id', id)
                .select()
                .single();
            
            if (error) throw error;
            console.log('✅ Task status updated');
            return data;
        }
    },
    
    // ============================================================
    // SHOPPING EXPENSES OPERATIONS
    // ============================================================
    
    shoppingExpenses: {
        async getAll(filters = {}) {
            await initializeDatabase();
            let query = supabase
                .from('shopping_expenses_detailed')
                .select('*')
                .order('transaction_date', { ascending: false });
            
            if (filters.month && filters.year) {
                const startDate = `${filters.year}-${filters.month.toString().padStart(2, '0')}-01`;
                const endDate = new Date(filters.year, filters.month, 0).toISOString().split('T')[0];
                query = query.gte('transaction_date', startDate).lte('transaction_date', endDate);
            }
            
            if (filters.property_id) {
                query = query.eq('property_id', filters.property_id);
            }
            
            if (filters.store_name) {
                query = query.ilike('store_name', `%${filters.store_name}%`);
            }
            
            if (filters.category) {
                query = query.eq('category', filters.category);
            }
            
            const { data, error } = await query;
            
            if (error) {
                console.error('❌ Error fetching shopping expenses:', error);
                throw error;
            }
            
            console.log(`🛒 Fetched ${data.length} shopping expenses`);
            return data;
        },
        
        async getCurrentMonth() {
            const now = new Date();
            return await this.getAll({
                month: now.getMonth() + 1,
                year: now.getFullYear()
            });
        },
        
        async getMonthlySummary(month, year) {
            await initializeDatabase();
            const { data, error } = await supabase
                .from('monthly_shopping_summary')
                .select('*')
                .eq('month', `${year}-${month.toString().padStart(2, '0')}-01`);
            
            if (error) throw error;
            return data;
        },
        
        async add(expense) {
            await initializeDatabase();
            
            // Ensure property_id is set
            if (expense.property_name && !expense.property_id) {
                const properties = await database.properties.getAll();
                const property = properties.find(p => p.name.toLowerCase().includes(expense.property_name.toLowerCase()));
                if (property) {
                    expense.property_id = property.id;
                    delete expense.property_name;
                }
            }
            
            const { data, error } = await supabase
                .from('shopping_expenses')
                .insert([expense])
                .select(`
                    *,
                    properties (name)
                `)
                .single();
            
            if (error) {
                console.error('❌ Error adding shopping expense:', error);
                throw error;
            }
            
            console.log('✅ Shopping expense added:', data.store_name);
            return data;
        },
        
        async update(id, updates) {
            await initializeDatabase();
            const { data, error } = await supabase
                .from('shopping_expenses')
                .update(updates)
                .eq('id', id)
                .select(`
                    *,
                    properties (name)
                `)
                .single();
            
            if (error) throw error;
            console.log('✅ Shopping expense updated');
            return data;
        },
        
        async delete(id) {
            await initializeDatabase();
            const { error } = await supabase
                .from('shopping_expenses')
                .delete()
                .eq('id', id);
            
            if (error) throw error;
            console.log('🗑️ Shopping expense deleted');
            return true;
        },
        
        async getByStore(storeName) {
            return await this.getAll({ store_name: storeName });
        },
        
        async getByProperty(propertyId) {
            return await this.getAll({ property_id: propertyId });
        },
        
        async getAnalytics(month, year) {
            const expenses = await this.getAll({ month, year });
            
            // Calculate analytics
            const totalSpent = expenses.reduce((sum, expense) => sum + expense.total_amount, 0);
            const avgTransaction = expenses.length > 0 ? totalSpent / expenses.length : 0;
            
            // Category breakdown
            const categoryBreakdown = expenses.reduce((acc, expense) => {
                acc[expense.category] = (acc[expense.category] || 0) + expense.total_amount;
                return acc;
            }, {});
            
            // Store frequency
            const storeFrequency = expenses.reduce((acc, expense) => {
                acc[expense.store_name] = (acc[expense.store_name] || 0) + 1;
                return acc;
            }, {});
            
            const topStore = Object.keys(storeFrequency).reduce((a, b) => 
                storeFrequency[a] > storeFrequency[b] ? a : b, null
            );
            
            return {
                totalSpent,
                avgTransaction,
                transactionCount: expenses.length,
                categoryBreakdown,
                storeFrequency,
                topStore
            };
        }
    },
    
    // ============================================================
    // MIGRATION HELPERS
    // ============================================================
    
    migration: {
        /**
         * Migrate existing localStorage data to Supabase
         */
        async migrateLocalStorageData() {
            console.log('🔄 Starting data migration from localStorage...');
            
            try {
                // Migrate past bookings
                const pastBookings = JSON.parse(localStorage.getItem('pastBookings') || '[]');
                if (pastBookings.length > 0) {
                    console.log(`📅 Migrating ${pastBookings.length} past bookings...`);
                    for (const booking of pastBookings) {
                        await database.bookings.add(booking);
                    }
                }
                
                // Migrate manual contacts (if any)
                const manualContacts = JSON.parse(localStorage.getItem('manualContacts') || '[]');
                if (manualContacts.length > 0) {
                    console.log(`👥 Migrating ${manualContacts.length} manual contacts...`);
                    for (const contact of manualContacts) {
                        await database.contacts.add(contact);
                    }
                }
                
                // Migrate tasks (if any)
                const tasks = JSON.parse(localStorage.getItem('tasks') || '[]');
                if (tasks.length > 0) {
                    console.log(`📋 Migrating ${tasks.length} tasks...`);
                    for (const task of tasks) {
                        await database.tasks.add(task);
                    }
                }
                
                console.log('✅ Migration completed successfully!');
                return true;
                
            } catch (error) {
                console.error('❌ Migration failed:', error);
                throw error;
            }
        },
        
        /**
         * Test database connection
         */
        async testConnection() {
            try {
                await initializeDatabase();
                const properties = await database.properties.getAll();
                console.log('✅ Database connection test successful');
                return { success: true, propertiesCount: properties.length };
            } catch (error) {
                console.error('❌ Database connection test failed:', error);
                return { success: false, error: error.message };
            }
        }
    }
};

// ============================================================
// UTILITY FUNCTIONS
// ============================================================

/**
 * Format date for database storage
 */
function formatDateForDB(date) {
    if (date instanceof Date) {
        return date.toISOString().split('T')[0];
    }
    return date;
}

/**
 * Parse date from database
 */
function parseDateFromDB(dateString) {
    return new Date(dateString);
}

/**
 * Check if database is initialized
 */
function isDatabaseInitialized() {
    return supabase !== null;
}

// ============================================================
// EXPORT FOR GLOBAL ACCESS
// ============================================================

// Make database object globally available
window.database = database;
window.initializeDatabase = initializeDatabase;

console.log('📦 Database abstraction layer loaded');